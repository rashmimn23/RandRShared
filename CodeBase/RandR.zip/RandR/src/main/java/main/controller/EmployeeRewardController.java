package main.controller;


import main.bean.EmployeeReward;

import main.bean.VoucherData;
import main.service.EmployeeRewardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/employeeRewards")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRewardController {

    @Autowired
    private EmployeeRewardService employeeRewardService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeReward createEmployee(@Valid @RequestBody EmployeeReward employeeReward) {
        return employeeRewardService.save( employeeReward );
    }

    @PostMapping("/excelReader")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> excelReader(@RequestParam("file") MultipartFile excelDatafile, @RequestParam("EMP_ID") final Integer empId) {
        return employeeRewardService.readExcel( excelDatafile, empId );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getAll() {
        return employeeRewardService.findAll();
    }

    /*  to retrieve by employee id*/
    @GetMapping("/getByEmployeeId/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getId(@PathVariable("EMP_ID") final Integer EMP_ID) {
        return employeeRewardService.getId( EMP_ID );
    }

    // to retrieve by employee id
    @GetMapping("/getByManagerId/{MANAGER_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getByManagerId(@PathVariable("MANAGER_ID") final Integer MANAGER_ID) {
        return employeeRewardService.getByManagerId( MANAGER_ID );
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeReward update(@RequestBody EmployeeReward employeeReward) {
        return employeeRewardService.update( employeeReward );
    }


    //To update status
    @PutMapping("/statusUpdate/{STATUS}")
    @ResponseStatus(HttpStatus.OK)
    public void statusUpdate(@Valid @RequestBody List<Long> idList, @PathVariable("STATUS") final String status) {
        employeeRewardService.statusUpdate( idList, status );
    }

    //To delete
    @DeleteMapping("/deleteById/{ID}")
    @ResponseStatus(HttpStatus.OK)
    public void delete(@PathVariable("ID") final Long id) {
        employeeRewardService.delete( id );
    }

    //To update AdvanceCompOff
    @PutMapping("/updateAdvanceCompOff/{ADVANCE_COMPOFF}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> updateAdvanceCompOff(@Valid @RequestBody List<Long> idList, @PathVariable("ADVANCE_COMPOFF") final String advanceCompOff) {
        return employeeRewardService.updateAdvanceCompOff( idList, advanceCompOff );
    }
}
