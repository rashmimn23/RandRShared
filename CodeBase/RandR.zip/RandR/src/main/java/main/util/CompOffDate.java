package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CompOffDate {

    // Get calendar Month
    public Calendar getCalendarMonth(String month, Integer year) {

        Calendar c = Calendar.getInstance();
        c.set( Calendar.YEAR, year );
        c.set( Calendar.DAY_OF_MONTH, 1 );

        //To set the month
        switch (month) {
            case "January":
                c.set( Calendar.MONTH, 0 );
                break;
            case "February":
                c.set( Calendar.MONTH, 1 );
                break;
            case "March":
                c.set( Calendar.MONTH, 2 );
                break;
            case "April":
                c.set( Calendar.MONTH, 3 );
                break;
            case "May":
                c.set( Calendar.MONTH, 4 );
                break;
            case "June":
                c.set( Calendar.MONTH, 5 );
                break;
            case "July":
                c.set( Calendar.MONTH, 6 );
                break;
            case "August":
                c.set( Calendar.MONTH, 7 );
                break;
            case "September":
                c.set( Calendar.MONTH, 8 );
                break;
            case "October":
                c.set( Calendar.MONTH, 9 );
                break;
            case "November":
                c.set( Calendar.MONTH, 10 );
                break;
            case "December":
                c.set( Calendar.MONTH, 11 );
                break;
        }
        return c;
    }

    // Get 3 month old start date and current month end date(Ex. If month=December then startdate= 01-10-2019 amd 31-12-2019)
    public List<Date> getMonthList(String month, Integer year) {

        List<Date> dates = new ArrayList<>();
        Calendar c = getCalendarMonth( month, year );
        Calendar c1 = getCalendarMonth( month, year );

        c.add( Calendar.MONTH, -2 );
        Date startDate = c.getTime();
        c1.set( Calendar.DAY_OF_MONTH, c1.getActualMaximum( Calendar.DAY_OF_MONTH ) );
        Date endDate = c1.getTime();
        dates.add( startDate );
        dates.add( endDate );
        System.out.println( dates );
        return dates;
    }

    // Get current month start and end date(Ex. If month=December then 01-12-2019 amd 31-12-2019
    public List<Date> getCurrentMonthList(String month, Integer year) {

        List<Date> dates = new ArrayList<>();
        Calendar c = getCalendarMonth( month, year );
        Calendar c1 = getCalendarMonth( month, year );

        Date startDate = c.getTime();
        c1.set( Calendar.DAY_OF_MONTH, c1.getActualMaximum( Calendar.DAY_OF_MONTH ) );
        Date endDate = c1.getTime();
        dates.add( startDate );
        dates.add( endDate );
        System.out.println( dates );
        return dates;
    }

    //get startdate and enddate of quarter
    public List<Date> getQuarterList(String quarter, Integer year) {

        List<Date> dates = new ArrayList<>();

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.set( Calendar.YEAR, year );
        c2.set( Calendar.YEAR, year );

        if (quarter.equals( "Q1" )) {
            c1.set( Calendar.MONTH, 3 );
            c2.set( Calendar.MONTH, 5 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q2" )) {
            c1.set( Calendar.MONTH, 6 );
            c2.set( Calendar.MONTH, 8 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q3" )) {
            c1.set( Calendar.MONTH, 9 );
            c2.set( Calendar.MONTH, 11 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
        }

        if (quarter.equals( "Q4" )) {
            c1.set( Calendar.MONTH, 0 );
            c2.set( Calendar.MONTH, 2 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
            c1.set( Calendar.YEAR, year+1 );
            c2.set( Calendar.YEAR, year+1 );
        }

        Date date1 = c1.getTime();
        Date date2 = c2.getTime();
        dates.add( date1 );
        dates.add( date2 );
        return dates;
    }

    public List<String> retrieveTerm(String quarter, Integer year) {
        List<String> termList = new ArrayList<String>();
        if (quarter.equals( "Q1" )) {
            termList.add( "Q1" + "-" + year );
            termList.add( "04" + "-" + year );
            termList.add( "05" + "-" + year );
            termList.add( "06" + "-" + year );
        } else if (quarter.equals( "Q2" )) {
            termList.add( "Q2" + "-" + year );
            termList.add( "07" + "-" + year );
            termList.add( "08" + "-" + year );
            termList.add( "09" + "-" + year );
        } else if (quarter.equals( "Q3" )) {
            termList.add( "Q3" + "-" + year );
            termList.add( "10" + "-" + year );
            termList.add( "11" + "-" + year );
            termList.add( "12" + "-" + year );
        } else if (quarter.equals( "Q4" )) {
            termList.add( "Q4" + "-" + year );
            year=year+1;
            termList.add( "01" + "-" + year );
            termList.add( "02" + "-" + year );
            termList.add( "03" + "-" + year );
        }
        return termList;
    }
}