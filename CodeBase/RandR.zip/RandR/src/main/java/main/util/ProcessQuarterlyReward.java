package main.util;

import main.bean.EmployeeReward;
import main.bean.Nomination;
import main.bean.VoucherData;
import main.repository.EmployeeRewardRepository;
import main.repository.VoucherDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class ProcessQuarterlyReward {
    @Autowired
    private CompOffDate compOffDate;
    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;
    @Autowired
    private VoucherDataRepository voucherDataRepository;

    public List<VoucherData> processQuarterlyReward(List<VoucherData> voucherDataList, String quarter, Integer year) {

        try {
            // Insert to VoucherData Table
            Date date = FormatDate.getCurrentDate();
            voucherDataList.stream().forEach( empVoucher -> empVoucher.setAllotedDate( date ) );
            voucherDataRepository.saveAll( voucherDataList );

            // Update status in employeereward table to VoucherAlloted
            List<EmployeeReward> employeeRewardList = new ArrayList<>();
            List<Date> dates = compOffDate.getQuarterList( quarter, year );

            for (VoucherData voucherData : voucherDataList) {
                employeeRewardList = employeeRewardRepository.getQuarterListByEmployee( voucherData.getEmpId(), "Approved", "No", dates.get( 0 ), dates.get( 1 ) );
                employeeRewardList.stream().forEach( employeeReward -> employeeRewardRepository.updateStatus( employeeReward.getId(), "VoucherAlloted" ) );
            }

            return voucherDataList;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

}
