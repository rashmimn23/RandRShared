package main.util;

import main.bean.NominationCriteria;
import main.bean.NominationRemark;
import main.service.NominationCriteriaService;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Component
public class GetCriteriaId {

    private static List<NominationCriteria> nominationCriteriaList;

    @Autowired
    private NominationCriteriaService nominationCriteriaService;

    private void getAllCriteria(String rewardType) {
        nominationCriteriaList = nominationCriteriaService.getId( rewardType );
    }

    public List<NominationRemark> extractRemarkHeader(List<NominationRemark> nominationRemarkHeader, String rewardType, Row row) {
        String criteria = null;
        List<String> criteriaList=nominationCriteriaService.getOnlyCriteria(rewardType);
        int criteriaSize=criteriaList.size();
        for (int i = 8; i < (8+criteriaSize); i++) {
            NominationRemark nominationRemark = new NominationRemark();
            criteria = row.getCell( i ).getStringCellValue();
            nominationRemark.setCriteriaId( getCriteriaId( criteria, rewardType ) );
            nominationRemarkHeader.add( nominationRemark );
        }
        nominationCriteriaList=null;
        return nominationRemarkHeader;
    }

    public Integer getCriteriaId(String criteria, String rewardType) {
        Integer criteriaId = null;
        if (CollectionUtils.isEmpty( nominationCriteriaList )) {
            getAllCriteria( rewardType );
        }
        Optional<NominationCriteria> nominationCriteria = nominationCriteriaList.stream().filter( nominationCriteriaData -> nominationCriteriaData.getCriteria().equals( criteria ) ).findFirst();
        if (nominationCriteria.isPresent()) {
            criteriaId = nominationCriteria.get().getCriteriaId();
        }
        return criteriaId;
    }
}
