package main.service;

import main.bean.VoucherData;
import main.reports.VoucherDataDownload;
import main.repository.VoucherDataRepository;
import main.util.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;

@Service
public class VoucherDataService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );

    @Autowired
    private VoucherDataRepository voucherDataRepository;

    @Autowired
    private QuarterlyNomination quarterlyNomination;

    @Autowired
    private QuarterlyReward quarterlyReward;

    @Autowired
    private ProcessQuarterlyNomination processQuarterlyNomination;

    @Autowired
    private ProcessQuarterlyReward processQuarterlyReward;

    @Autowired
    private VoucherDataDownload voucherDataDownload;

    // to get all
    public List<VoucherData> getAll() {
        try {
            return voucherDataRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public List<VoucherData> getQuarterlyNomination(String quarter, Integer year) {
        try {
            return quarterlyNomination.quarterlyNomination( quarter, year );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public List<VoucherData> getQuarterlyReward(String quarter, Integer year) {
        try {
            return quarterlyReward.quarterlyReward( quarter, year );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public List<VoucherData> processQuarterlyNomination(List<VoucherData> voucherData, String quarter, Integer year) {
        try {
            return processQuarterlyNomination.processQuarterlyNomination( voucherData, quarter, year );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public List<VoucherData> processQuarterlyReward(List<VoucherData> voucherData, String quarter, Integer year) {
        try {
            return processQuarterlyReward.processQuarterlyReward( voucherData, quarter, year );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public XSSFWorkbook downloadQuarterlyVoucher(String quarter, Integer year, String rewardType) {
        try {
            return voucherDataDownload.voucherDataDownload( quarter, year, rewardType );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

}
