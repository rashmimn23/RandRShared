package main.service;

import main.bean.Nomination;
import main.bean.NominationRemark;
import main.bean.PointsValue;
import main.repository.NominationRemarkRepository;
import main.repository.NominationRepository;
import main.util.FormatDate;
import main.reports.NominationDetailsDownload;
import main.util.NominationExcelReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Service
public class NominationService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );
    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    @Autowired
    NominationExcelReader nominationExcelReader;

    @Autowired
    private PointsValueService pointsValueService;

    @Autowired
    private NominationDetailsDownload nominationDetailsDownload;

    // retrieve all employeerole details
    public List<Nomination> findAll() {
        try {
            return nominationRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //   Get by Nominee id
    public List<Nomination> getByNomineeId(Integer nomineeId) {
        try {
            return nominationRepository.findByNomineeId( nomineeId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //   Get by an managerId
    public List<Nomination> getByManagerId(Integer managerId) {
        try {
            return nominationRepository.findByManagerId( managerId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //  to update
    @Transactional
    public Nomination update(Nomination nomination) {
        try {
            List<NominationRemark> nominationRemarkList = nomination.getNominationRemarkList();
            Nomination nominationParam = nominationRepository.save( nomination );
            List<NominationRemark> nominationRemarkListParam = nominationRemarkRepository.saveAll( nominationRemarkList );
            nominationParam.setNominationRemarkList( nominationRemarkListParam );
            return nominationParam;
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // insert nomination and remarks
    @Transactional
    public Nomination saveNomination(Nomination nomination) {
        try {
            //set NominationDate as current date
            nomination.setNominationDate( FormatDate.getCurrentDate() );

            //Set default NominationStatus as Pending
            nomination.setNominationStatus( "Pending" );

            Nomination nominationParam = nominationRepository.save( nomination );
            Long nominationId = nominationParam.getId();
            List<NominationRemark> nominationRemarkList = nominationParam.getNominationRemarkList();

            nominationRemarkList.stream().forEach( nominationRemark -> nominationRemark.setId( nominationId ) );

            nominationRemarkList = nominationRemarkRepository.saveAll( nominationRemarkList );
            nominationParam.setNominationRemarkList( nominationRemarkList );
            return nominationParam;
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // Upload Nomination excel

    public List<Nomination> saveExcelNomination(MultipartFile file, String rewardType)  {
        try {
            List<Nomination> nominations = nominationExcelReader.read( file, rewardType );
            return nominations;
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //to delete
    public void delete(Long id) {
        try {
            nominationRemarkRepository.deleteInRemark( id );
            nominationRepository.deleteInNomination( id );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }

    //To Update Status
    public void statusUpdate(Long id, String rewardType, String nominationStatus) {
        try {
            String status = nominationStatus;
            if (status.equals( "Approved" )) {
                PointsValue pointsValue = pointsValueService.findByRewardType( rewardType );
                Integer points = pointsValue.getPoints();
                nominationRepository.updateStatus( id, points, nominationStatus );
            } else {
                Integer points1 = 0;
                nominationRepository.updateStatus( id, points1, nominationStatus );
            }
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }

    //to retrieve nomination for that quarter who are approved
    public XSSFWorkbook downloadNominaionDetails(String quarter, Integer year, List<String> statusList) {
        try {
            return nominationDetailsDownload.downloadNominaionDetails( quarter, year, statusList );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

}
