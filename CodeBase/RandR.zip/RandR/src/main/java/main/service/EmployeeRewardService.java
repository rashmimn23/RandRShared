package main.service;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import main.reports.WeekendDetailsDownload;
import main.util.CalculatePoints;
import main.util.WeekendExcelReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRewardService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );
    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    @Autowired
    private WeekendExcelReader weekendExcelReader;

    @Autowired
    private WeekendDetailsDownload weekendDetailsDownload;

    @Autowired
    private CalculatePoints calculatePoints;

    //   To save
    public EmployeeReward save(EmployeeReward employeeReward) {
        try {
            return employeeRewardRepository.save( employeeReward );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // retrieve all employeerole details
    public List<EmployeeReward> findAll() {
        try {
            return employeeRewardRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //    Get by employee id
    public List<EmployeeReward> getId(Integer EMP_ID) {
        try {
            return employeeRewardRepository.findByEmpId( EMP_ID );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //    Get by manager id
    public List<EmployeeReward> getByManagerId(Integer EMP_ID) {
        try {
            return employeeRewardRepository.findByManagerId( EMP_ID );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //    to update
    public EmployeeReward update(EmployeeReward employeeReward) {
        try {
            Integer points = calculatePoints.calculateTotalPoints( employeeReward.getRewardType(), employeeReward.getNoOfInterviews() );
            employeeReward.setNoOfPoints( points );
            return employeeRewardRepository.save( employeeReward );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To delete all
    public void delete(Long id) {
        try {
            employeeRewardRepository.deleteById( id );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }

    //To Update Status
    public void statusUpdate(List<Long> idList, String status) {
        try {
            for (Long id : idList) {
                if (status.equals( "Approved" ) || status.equals( "Rejected" )) {
                    employeeRewardRepository.updateStatus( id, status );
                }
            }
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );

        }
    }


    public Optional<EmployeeReward> getById(Long id) {
        try {
            return employeeRewardRepository.findById( id );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public List<EmployeeReward> readExcel(MultipartFile file, Integer empId) {
        try {
            List<EmployeeReward> employeeEntities = weekendExcelReader.read( file, empId );
            return employeeEntities;
        } catch (
                Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To update AdvanceCompOff
    public List<EmployeeReward> updateAdvanceCompOff(List<Long> idList, String advanceCompOff) {
        try {
            for (Long id : idList) {
                employeeRewardRepository.updateAdvanceCompOffRepo( id, advanceCompOff, 0 );
            }
            return employeeRewardRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    /*  to retrieve weekend details between two dates*/
    public XSSFWorkbook downloadWeekendDetails(Date startDate, Date endDate, List<String> statusList) {
        try {
            return weekendDetailsDownload.downloadWeekendDetails( startDate, endDate, statusList );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }
}