package main.service;

import main.bean.EmployeeCompOff;
import main.repository.EmployeeCompOffRepository;
import main.reports.CompOffExceptionDownload;
import main.util.ConsolidatedCompOffExcelReader;
import main.util.UpdateEmployeeCompOff;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeCompOffService {
    private static final Logger LOGGER = LogManager.getLogger(EmployeeRoleService.class);
    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    @Autowired
    private ConsolidatedCompOffExcelReader consolidatedCompOffExcelReader;

    @Autowired
    private UpdateEmployeeCompOff updateEmployeeCompOff;
    @Autowired
    private CompOffExceptionDownload compOffExceptionDownload;

    // Fetch CompOff Details
    public List<EmployeeCompOff> readCompOffExcel(String month, Integer year, MultipartFile compOffFile, MultipartFile employeeProjectInfo) {
        try {
            List<EmployeeCompOff> employeeCompOffs = consolidatedCompOffExcelReader.readExcelCompOff( month, year, compOffFile, employeeProjectInfo );
            return employeeCompOffs;
        }
        catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To save
    public EmployeeCompOff save(EmployeeCompOff employeeCompOff) {
        try {
            return employeeCompOffRepository.save( employeeCompOff );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To retreive all
    public List<EmployeeCompOff> getAll() {
        try {
            return employeeCompOffRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To update
    public EmployeeCompOff update(EmployeeCompOff employeeCompOff) {
        try {
            return employeeCompOffRepository.save( employeeCompOff );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public String updateCompOffList(List<EmployeeCompOff> employeeCompOffList) {
        try {
            return updateEmployeeCompOff.updateEmployeeCompOff( employeeCompOffList );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //To delete using empId
    public void deleteByEmpId(Integer empId) {
        try {
            employeeCompOffRepository.deleteByEmpId( empId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }

    //To delete using Id
    public void deleteById(Long compOffId) {
        try {
            employeeCompOffRepository.deleteById( compOffId );
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }


    public XSSFWorkbook downloadCompoffException(String month, Integer year) {
        try {
            return compOffExceptionDownload.compOffExceptionDownload( month, year );
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return null;
        }
    }
}



