package main.service;

import main.bean.EmployeeRole;
import main.repository.EmployeeRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class EmployeeRoleService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );
    @Autowired
    private EmployeeRoleRepository employeeRoleRepository;

    /*    To save */
    public EmployeeRole save(EmployeeRole employeerole) {
        try {
            return employeeRoleRepository.save( employeerole );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    /* retrieve all employeerole details*/
    public List<EmployeeRole> findAll() {
        try {
            return employeeRoleRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    /*    Get by an id*/
    public Optional<EmployeeRole> findById(Integer EMP_ID) {
        try {
            return employeeRoleRepository.findById( EMP_ID );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return Optional.empty();
        }
    }

    /*    to update*/
    public EmployeeRole update(EmployeeRole employeerole) {
        try {
            return employeeRoleRepository.save( employeerole );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    public Optional<EmployeeRole> getRole(Integer EMP_ID, String PASSWORD) {
        try {
            //  String emp_role = null;
            Optional<EmployeeRole> employee = findById( EMP_ID );
            Optional<EmployeeRole> employeeRole = null;
            if (employee.isPresent()) {
                String emp_password = employee.get().getPassword();
                if (emp_password.equals( PASSWORD )) {
                    employeeRole = employee;
                    LOGGER.info( employee );
                } else {
                    LOGGER.error( "Invalid Password" );
                }
            } else {
                LOGGER.error( "Invalid Username" );
            }
            return employeeRole;
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return Optional.empty();
        }
    }

    //To delete all
    public void delete(Integer empId) {
        try {
            employeeRoleRepository.deleteById( empId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }
}