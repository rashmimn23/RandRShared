package main.service;

import main.bean.PointsValue;
import main.repository.PointsValueRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PointsValueService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );
    @Autowired
    private PointsValueRepository pointsValueRepository;

    // to save
    public PointsValue save(PointsValue pointsValue) {
        try {
            return pointsValueRepository.save( pointsValue );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // to get all
    public List<PointsValue> getAll() {
        try {
            return pointsValueRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // to get by id
    public PointsValue findByRewardType(String reward_type) {
        try {
            return pointsValueRepository.findByRewardType( reward_type );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //    to update
    public PointsValue update(PointsValue pointsValue) {
        try {
            return pointsValueRepository.save( pointsValue );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //to delete
    public void delete(Integer pointsId) {
        try {
            pointsValueRepository.deleteById( pointsId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
         }
    }
}
