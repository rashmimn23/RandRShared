package main.service;

import main.bean.NominationRemark;
import main.repository.NominationRemarkRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NominationRemarkService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );
    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    //   To save
    public NominationRemark save(NominationRemark nominationRemark) {
        try {
            return nominationRemarkRepository.save( nominationRemark );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    // retrieve all employeerole details
    public List<NominationRemark> findAll() {
        try {
            return nominationRemarkRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

        //    Get by an id
        public Optional<NominationRemark> getId (Long id){
            try {
                return nominationRemarkRepository.findById( id );
            } catch (Exception e) {
                LOGGER.error( e.getMessage(), e );
                return null;
            }
        }

        //    to update
        public NominationRemark update (NominationRemark nominationRemark){
            try {
                return nominationRemarkRepository.save( nominationRemark );
            } catch (Exception e) {
                LOGGER.error( e.getMessage(), e );
                return null;
            }
        }
    }
