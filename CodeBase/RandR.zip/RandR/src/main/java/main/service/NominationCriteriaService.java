package main.service;

import main.bean.NominationCriteria;
import main.repository.NominationCriteriaRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NominationCriteriaService {
    private static final Logger LOGGER = LogManager.getLogger( EmployeeRoleService.class );

    @Autowired
    private NominationCriteriaRepository nominationCriteriaRepository;

// To save

    public NominationCriteria save(NominationCriteria nominationCriteria) {
        try {
            return nominationCriteriaRepository.save( nominationCriteria );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

// retrieve all employeerole details

    public List<NominationCriteria> findAll() {
        try {
            return nominationCriteriaRepository.findAll();
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

//    Get by an id

    public List<NominationCriteria> getId(String rewardType) {
        try {
            return nominationCriteriaRepository.findByRewardType( rewardType );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //    Get only List of id's of Question
    public List<String> getOnlyCriteria(String rewardType) {
        try {
            return nominationCriteriaRepository.getOnlyCriteria( rewardType );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

// to update

    public NominationCriteria update(NominationCriteria nominationCriteria) {
        try {
            return nominationCriteriaRepository.save( nominationCriteria );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
            return null;
        }
    }

    //to delete criteria
    public void delete(Integer criteriaId) {
        try {
            nominationCriteriaRepository.deleteById( criteriaId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }

    //to delete criterias for specific reward type
    public void deleteByRewardType(String criteriaId) {
        try {
            nominationCriteriaRepository.deleteByRewardType( criteriaId );
        } catch (Exception e) {
            LOGGER.error( e.getMessage(), e );
        }
    }
}
