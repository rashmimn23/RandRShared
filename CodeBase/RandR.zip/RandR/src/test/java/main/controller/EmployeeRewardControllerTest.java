package main.controller;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeReward;
import main.service.EmployeeRewardService;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeRewardControllerTest {

    @InjectMocks
    private EmployeeRewardController employeeRewardController;
    @Mock
    private EmployeeRewardService employeeRewardService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private EmployeeReward mockEmployeeReward() {
        EmployeeReward employeeReward = new EmployeeReward();
        employeeReward.setEmpId( 1234567 );
        employeeReward.setEmpName( "Aakash" );
        employeeReward.setManagerId( 9876543 );
        employeeReward.setNoOfPoints( 500 );
        employeeReward.setRewardType( "Interview_Telephonic" );
        employeeReward.setNoOfInterviews( 5 );
        return employeeReward;
    }

    private List<EmployeeReward> mockEmployeeRewardList() {
        List<EmployeeReward> employeeRewardList = new ArrayList<>();
        employeeRewardList.add( mockEmployeeReward() );
        employeeRewardList.add( mockEmployeeReward() );
        employeeRewardList.get( 0 ).setEmpId( 4567891 );
        return employeeRewardList;
    }

    @Test
    public void createEmployee() {
        EmployeeReward mockEmployeeReward = mockEmployeeReward();

        Mockito.when( employeeRewardService.save( any( EmployeeReward.class ) ) ).thenReturn( mockEmployeeReward );
        EmployeeReward employeeReward = employeeRewardController.createEmployee( mockEmployeeReward );
        assert (employeeReward.getEmpId() == 1234567);
    }

    @Test
    public void excelReader() {
        MultipartFile excelDatafile = null;
        Mockito.when( employeeRewardService.readExcel( any( MultipartFile.class ), anyInt() ) ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> employeeReward = employeeRewardController.excelReader( excelDatafile, 1234567 );
        assert (employeeReward.get( 0 ).getEmpId() == 4567891);
    }

    @Test
    public void getAll() {
        Mockito.when( employeeRewardService.findAll() ).thenReturn( Arrays.asList( mockEmployeeReward() ) );
        List<EmployeeReward> employeeRewardList = employeeRewardController.getAll();
        assertTrue( !CollectionUtils.isEmpty( employeeRewardList ) );
    }

    @Test
    public void getId() {
        Mockito.when( employeeRewardService.getId( 1234567 ) ).thenReturn(mockEmployeeRewardList() );
        List<EmployeeReward> employeeRewardList = employeeRewardController.getId( 1234567 );
        assertTrue( !CollectionUtils.isEmpty( employeeRewardList ) );
    }

    @Test
    public void getByManagerId() {
        Mockito.when( employeeRewardService.getByManagerId( 9876543 ) ).thenReturn( mockEmployeeRewardList()  );
        List<EmployeeReward> employeeRewardList = employeeRewardController.getByManagerId( 9876543 );
        assertTrue( !CollectionUtils.isEmpty( employeeRewardList ) );
    }

    @Test
    public void update() {
        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        Mockito.when( employeeRewardService.update( any( EmployeeReward.class )) ).thenReturn( mockEmployeeReward );
        Assert.assertEquals( mockEmployeeReward, employeeRewardController.update( mockEmployeeReward) );
    }

    @Test
    public void statusUpdate() {
        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        employeeRewardController.statusUpdate(  idList, "Approved"  );
        verify( employeeRewardService, times( 1 ) ).statusUpdate(anyListOf( Long.class ), anyString() );

    }

    @Test
    public void delete() {
        employeeRewardController.delete( (long) 1234567 );
        verify( employeeRewardService, times( 1 ) ).delete( (long) 1234567 );
    }

    @Test
    public void updateAdvanceCompOff() {

        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        Mockito.when( employeeRewardService.updateAdvanceCompOff(anyListOf( Long.class ), anyString()) ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardController.updateAdvanceCompOff( idList, "Yes" );

        assert (response.get( 0 ).getEmpId() == 4567891);
        verify( employeeRewardService, times( 1 ) ).updateAdvanceCompOff( idList, "Yes");
    }
}