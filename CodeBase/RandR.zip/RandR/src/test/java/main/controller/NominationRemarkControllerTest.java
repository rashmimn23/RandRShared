package main.controller;

import main.bean.NominationRemark;
import main.service.NominationRemarkService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;

@RunWith(MockitoJUnitRunner.class)
public class NominationRemarkControllerTest {

    @InjectMocks
    private NominationRemarkController nominationRemarkController;

    @Mock
    private NominationRemarkService nominationRemarkService;

    @BeforeEach
    public void setUp() {  MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    public  void tearDown() {
    }

    private NominationRemark getNominationRemark() {
        NominationRemark nominationRemark = new NominationRemark( 1, (long)1, 1, "R and R reognition" );
        return nominationRemark;
    }

    @Test
    public void createEmployee() {
        NominationRemark mockNominationRemark=getNominationRemark();
        Mockito.when( nominationRemarkService.save( any(NominationRemark.class) ) ).thenReturn( mockNominationRemark );
        NominationRemark nominationRemark = nominationRemarkController.createEmployee( mockNominationRemark );
        assert (nominationRemark.getRemarkId() == 1);
    }

    @Test
    public void getAll() {
        Mockito.when( nominationRemarkService.findAll() ).thenReturn( Arrays.asList( getNominationRemark() ) );
        List<NominationRemark>  nominationRemarkList = nominationRemarkController.getAll();
        assertTrue( !CollectionUtils.isEmpty( nominationRemarkList ) );
    }

    @Test
    public void getId() {
        Mockito.when( nominationRemarkService.getId( anyLong())).thenReturn( Optional.of(getNominationRemark()) );
        Optional<NominationRemark> nominationRemark = nominationRemarkController.getId( (long) 1);
        assert (nominationRemark.get().getRemark() == "R and R reognition");
    }

    @Test
    public void update() {
        NominationRemark mockNominationRemark=getNominationRemark();
        Mockito.when( nominationRemarkService.update(any(NominationRemark.class) ) ).thenReturn( mockNominationRemark );
        NominationRemark nominationRemark = nominationRemarkController.update( mockNominationRemark);
        assert (nominationRemark.getRemarkId() == 1);
    }
}