package main.controller;

import main.bean.EmployeeRole;
import main.service.EmployeeRoleService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeRoleControllerTest {
    @InjectMocks
    private EmployeeRoleController employeeRoleController;
    @Mock
    private EmployeeRoleService employeeRoleService;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception {
    }

    private EmployeeRole getMockEmployeeRole() {
        EmployeeRole employeeRole = new EmployeeRole(194878, "Rashmi", "Lead", 194868, "rashmi123");
        return employeeRole;
    }

    @Test
    public void createEmployee() {
        EmployeeRole mockEmployeeRole = getMockEmployeeRole();
        Mockito.when(employeeRoleService.save(any(EmployeeRole.class))).thenReturn(mockEmployeeRole);
        EmployeeRole response = employeeRoleController.createEmployee(mockEmployeeRole);
        assert (response.getEmpId() == 194878);
    }

    @Test
    public void getAll() {
        Mockito.when(employeeRoleService.findAll()).thenReturn(Arrays.asList(getMockEmployeeRole()));
        List<EmployeeRole> employeeRoleList = employeeRoleController.getAll();
        assertTrue(!CollectionUtils.isEmpty(employeeRoleList));
    }

    @Test
    public void getId() {
        Mockito.when(employeeRoleService.findById(anyInt())).thenReturn(Optional.of(getMockEmployeeRole()));
        Optional<EmployeeRole> employeeRole = employeeRoleController.getId(194878);
        assert (employeeRole.get().getEmpId() == 194878);
    }

    @Test
    public void update() {
        EmployeeRole mockEmployeeRole = getMockEmployeeRole();
        Mockito.when(employeeRoleService.update(any(EmployeeRole.class))).thenReturn(mockEmployeeRole);
        EmployeeRole response = employeeRoleController.update(mockEmployeeRole);
        assert (response.getEmpId() == 194878);
    }

    @Test
    public void getRoleSuccess() {
        Mockito.when(employeeRoleService.getRole(anyInt(), anyString())).thenReturn(Optional.of(getMockEmployeeRole()));
        ResponseEntity<Object> responseEntitySuccess = employeeRoleController.getRole(194878, "rashmi123");
        assert (responseEntitySuccess.getStatusCodeValue() == 200);
    }

    @Test
    public void getRoleFailure() {
        Mockito.when(employeeRoleService.getRole(194878, "rashmi123")).thenReturn(Optional.of(getMockEmployeeRole()));
        ResponseEntity<Object> responseEntity = employeeRoleController.getRole(1, "pwd");
        assertTrue(responseEntity.getBody() == "InvalidLogin");
    }

    @Test
    public void delete() {
        employeeRoleController.delete(194878);
        verify(employeeRoleService, times(1)).delete(194878);
    }
}