package main.controller;

import main.bean.PointsValue;
import main.service.PointsValueService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PointsValueControllerTest {

    @InjectMocks
    private PointsValueController pointsValueController;
    @Mock
    private PointsValueService pointsValueService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private PointsValue getPointsValue() {
        PointsValue pointsValue = new PointsValue( 1, "Client_Appreciation", 100 );
        return pointsValue;
    }

    private List<PointsValue> getPointsValueList() {
        PointsValue pointsValue1 = new PointsValue( 1, "Client_Appreciation", 100 );
        PointsValue pointsValue2 = new PointsValue( 2, "Innovation_Award", 50 );
        List<PointsValue> pointsValueList = Arrays.asList( pointsValue1, pointsValue2 );
        return pointsValueList;
    }

    @Test
    public void createEmployee() {
        PointsValue mockPointsValue = getPointsValue();
        Mockito.when( pointsValueService.save(  any( PointsValue.class )) ).thenReturn(  mockPointsValue);
        PointsValue pointsValue = pointsValueController.createEmployee( mockPointsValue );
        assert (pointsValue.getRewardType() == "Client_Appreciation");
    }

    @Test
    public void getAll() {

        Mockito.when( pointsValueService.getAll() ).thenReturn( getPointsValueList() );
        List<PointsValue> pointsValueList = pointsValueController.getAll();

        assertTrue( !CollectionUtils.isEmpty( pointsValueList ) );
        assertTrue( pointsValueList.size() == 2 );
        assertTrue( pointsValueList.get( 0 ).getRewardType().equals( pointsValueList.get( 0 ).getRewardType() ) );
        assertTrue( pointsValueList.get( 1 ).getRewardType().equals( pointsValueList.get( 1 ).getRewardType() ) );
    }

    @Test
    public void getByRewardType() {

        Mockito.when( pointsValueService.findByRewardType( anyString() ) ).thenReturn( getPointsValue() );
        PointsValue pointsValue = pointsValueController.getByRewardType( "Client_Appreciation" );
        assert (pointsValue.getPoints() == 100);
    }

    @Test
    public void update() {
        PointsValue pointsValueMock = getPointsValue();
        pointsValueMock.setPoints( 600 );
        Mockito.when( pointsValueService.update( any( PointsValue.class )) ).thenReturn( pointsValueMock );
        PointsValue pointsValue = pointsValueController.update( pointsValueMock );

        assert (pointsValue.getPoints() == 600);
    }

    @Test
    public void delete() {

        pointsValueController.delete(1 );
        verify( pointsValueService, times( 1 ) ).delete( 1 );
    }
}