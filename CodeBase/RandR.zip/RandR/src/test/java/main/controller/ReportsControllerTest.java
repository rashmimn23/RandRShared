package main.controller;

import main.service.EmployeeCompOffService;
import main.service.EmployeeRewardService;
import main.service.NominationService;
import main.service.VoucherDataService;
import main.util.DownloadExcel;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletResponse;

import java.util.*;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ReportsControllerTest {

    @InjectMocks
    private ReportsController reportsController;
    @Mock
    private DownloadExcel downloadExcel;

    @Mock
    private VoucherDataService voucherDataService;

    @Mock
    private EmployeeRewardService employeeRewardService;

    @Mock
    private NominationService nominationService;

    @Mock
    private EmployeeCompOffService employeeCompOffService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void downloadQuarterlyVoucher() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadQuarterlyVoucher( "Q4", 2019, "Client_Appreciation", response );
        verify( voucherDataService, times( 1 ) ).downloadQuarterlyVoucher( anyString(), anyInt(), anyString() );
    }
    @Test
    public void downloadWeekendDetails() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        List<String> statusList = new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        Date startDate = new GregorianCalendar( 2020, Calendar.JANUARY, 11 ).getTime();
        Date endDate = new GregorianCalendar( 2020, Calendar.FEBRUARY, 11 ).getTime();
        reportsController.downloadWeekendDetails( startDate, endDate, statusList,response );
        verify( employeeRewardService, times( 1 ) ).downloadWeekendDetails( any( Date.class ), any( Date.class ), anyList() );
    }

    @Test
    public void downloadNominaionDetails() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        List<String > statusList=new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        reportsController.downloadNominaionDetails( "Q4", 2019,statusList , response );
        verify( nominationService, times( 1 ) ).downloadNominaionDetails( anyString(), anyInt(), anyListOf(String.class) );
    }

    @Test
    public void downloadCompoffException() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadCompoffException( "January", 2020 , response );
        verify( employeeCompOffService, times( 1 ) ).downloadCompoffException( anyString(), anyInt());
    }

/*    @Test
    public void downloadCompoffExceptionFailure() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( employeeCompOffService.downloadCompoffException( anyString(), anyInt() ) ).thenThrow( Exception.class );
        Assert.assertNull( reportsController.downloadCompoffException("January", 2020, response));
    }*/
}