package main.controller;

import main.service.EmployeeCompOffService;
import main.service.EmployeeRewardService;
import main.service.NominationService;
import main.service.VoucherDataService;
import main.util.DownloadExcel;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletResponse;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ReportsControllerTest {

    @InjectMocks
    private ReportsController reportsController;
    @Mock
    private DownloadExcel downloadExcel;

    @Mock
    private VoucherDataService voucherDataService;

    @Mock
    private EmployeeRewardService employeeRewardService;

    @Mock
    private NominationService nominationService;

    @Mock
    private EmployeeCompOffService employeeCompOffService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void downloadQuarterlyVoucher() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadQuarterlyVoucher( "Q4", 2019, "Client_Appreciation", response );
        verify( voucherDataService, times( 1 ) ).downloadQuarterlyVoucher( anyString(), anyInt(), anyString() );
    }

    @Test
    public void downloadWeekendDetails() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadWeekendDetails( "Q4", 2019, "Client_Appreciation", response );
        verify( employeeRewardService, times( 1 ) ).downloadWeekendDetails( anyString(), anyInt(), anyString() );
    }

    @Test
    public void downloadNominaionDetails() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadNominaionDetails( "Q4", 2019, "Client_Appreciation", response );
        verify( nominationService, times( 1 ) ).downloadNominaionDetails( anyString(), anyInt(), anyString() );
    }

    @Test
    public void downloadCompoffException() {
        HttpServletResponse response = null;
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        reportsController.downloadCompoffException( "Q4", 2019, "Client_Appreciation", response );
        verify( employeeCompOffService, times( 1 ) ).downloadCompoffException( anyString(), anyInt(), anyString() );
    }
}