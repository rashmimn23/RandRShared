package main.controller;

import main.bean.VoucherData;
import main.service.VoucherDataService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class VoucherDataControllerTest {

    @InjectMocks
    private VoucherDataController voucherDataController;
    @Mock
    private VoucherDataService voucherDataService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    public void tearDown() {
    }

    private List<VoucherData> getVoucherDataList() {
        VoucherData voucherData1 = new VoucherData(1234567, "Revati", 500, "Q4", 2020, "Client_Appreciation", "01-2020");
        VoucherData voucherData2 = new VoucherData(9876543, "Pranjal", 500, "Q4", 2020, "Innovation_Award", "02-2020");

        List<VoucherData> voucherDataList = Arrays.asList(voucherData1, voucherData2);
        return voucherDataList;
    }

    @Test
    public void getAll() {

        Mockito.when(voucherDataService.getAll()).thenReturn(getVoucherDataList());

        List<VoucherData> voucherDataList = voucherDataController.getAll();
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void getQuarterlyNomination() {
        Mockito.when(voucherDataService.getQuarterlyNomination("Q4", 2020)).thenReturn(getVoucherDataList());

        List<VoucherData> voucherDataList = voucherDataController.getQuarterlyNomination("Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void getQuarterlyReward() {
        Mockito.when(voucherDataService.getQuarterlyReward("Q4", 2020)).thenReturn(getVoucherDataList());
        List<VoucherData> voucherDataList = voucherDataController.getQuarterlyReward("Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void processQuarterlyNomination() {
        List<VoucherData> voucherDataList1 = getVoucherDataList();
        Mockito.when(voucherDataService.processQuarterlyNomination(voucherDataList1, "Q4", 2020)).thenReturn(getVoucherDataList());
        List<VoucherData> voucherDataList = voucherDataController.processQuarterlyNomination(voucherDataList1, "Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void processQuarterlyReward() {
        List<VoucherData> voucherDataList1 = getVoucherDataList();
        Mockito.when(voucherDataService.processQuarterlyReward(voucherDataList1, "Q4", 2020)).thenReturn(getVoucherDataList());
        List<VoucherData> voucherDataList = voucherDataController.processQuarterlyReward(voucherDataList1, "Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }
}