package main.controller;

import main.bean.NominationCriteria;
import main.service.NominationCriteriaService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NominationCriteriaControllerTest {

    @InjectMocks
    private NominationCriteriaController nominationCriteriaController;
    @Mock
    private NominationCriteriaService nominationCriteriaService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private NominationCriteria getMockNominationCriteria() {
        NominationCriteria nominationCriteria = new NominationCriteria( 1, "Client_Appreciation", "Team Size" );
        return nominationCriteria;
    }

    @Test
    public void createEmployee() {
        NominationCriteria mockNominationCriteria=getMockNominationCriteria();
        Mockito.when( nominationCriteriaService.save(  any( NominationCriteria.class )) ).thenReturn( mockNominationCriteria );

        NominationCriteria nominationCriteria = nominationCriteriaController.createEmployee( mockNominationCriteria );
        assert (nominationCriteria.getCriteriaId() == 1);
    }

    @Test
    public void getAll() {
        Mockito.when( nominationCriteriaService.findAll() ).thenReturn( Arrays.asList( getMockNominationCriteria() ) );
        List<NominationCriteria> nominationCriteriaList = nominationCriteriaController.getAll();
        assertTrue( !CollectionUtils.isEmpty( nominationCriteriaList ) );
    }

    @Test
    public void getId() {
        Mockito.when( nominationCriteriaService.getId( anyString()) ).thenReturn( Arrays.asList( getMockNominationCriteria() ) );
        List<NominationCriteria> nominationCriteriaList= nominationCriteriaController.getId( "Client_Appreciation" );
        assert (nominationCriteriaList.size() == 1);
    }

    @Test
    public void update() {
        NominationCriteria mockNominationCriteria=getMockNominationCriteria();
        Mockito.when( nominationCriteriaService.update(  any( NominationCriteria.class )) ).thenReturn( mockNominationCriteria );
        NominationCriteria nominationCriteria = nominationCriteriaController.update( mockNominationCriteria );
        assert (nominationCriteria.getCriteriaId() == 1);
    }

    @Test
    public void delete() {
        nominationCriteriaController.delete( 1 );
        verify(nominationCriteriaService, times(1)).delete(1);
    }

    @Test
    public void deleteByRewardType() {
        nominationCriteriaController.deleteByRewardType( "Client_Appreciation" );
        verify(nominationCriteriaService, times(1)).deleteByRewardType("Client_Appreciation");
    }
}