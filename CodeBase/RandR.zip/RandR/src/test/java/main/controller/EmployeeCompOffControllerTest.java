package main.controller;

import main.bean.EmployeeCompOff;
import main.service.EmployeeCompOffService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeCompOffControllerTest {

    @InjectMocks
    private EmployeeCompOffController employeeCompOffController;
    @Mock
    private EmployeeCompOffService employeeCompOffService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    public void tearDown() {
    }

    private EmployeeCompOff getMockEmployeeCompOff() {
        EmployeeCompOff employeeCompOff = new EmployeeCompOff((long) 1, 1234567);
        return employeeCompOff;
    }

    @Test
    public void compOffExcelReader() {
        MultipartFile compOffFile = null;
        MultipartFile employeeProjectInfo = null;
        employeeCompOffController.compOffExcelReader("January",2020,compOffFile,employeeProjectInfo);
        verify(employeeCompOffService, times(1)).readCompOffExcel("January",2020,compOffFile,employeeProjectInfo);
    }

    @Test
    public void getAll() {
        Mockito.when(employeeCompOffService.getAll()).thenReturn(Arrays.asList(getMockEmployeeCompOff()));
        List<EmployeeCompOff> employeeCompOffList = employeeCompOffController.getAll();
        assertTrue(!CollectionUtils.isEmpty(employeeCompOffList));
    }

    @Test
    public void updateCompOffList() {
        List<EmployeeCompOff> mockEmployeeCompOffList =Arrays.asList(getMockEmployeeCompOff());
        Mockito.when(employeeCompOffService.updateCompOffList(Arrays.asList(any(EmployeeCompOff.class)))).thenReturn("inserted");
        String output = employeeCompOffController.updateCompOffList(mockEmployeeCompOffList);
        assert (output == "inserted");
    }

    @Test
    public void deleteByEmpId() {
        employeeCompOffController.deleteByEmpId( 1234567);
        verify(employeeCompOffService, times(1)).deleteByEmpId( 1234567);
    }

    @Test
    public void deleteById() {
        employeeCompOffController.deleteById((long) 1);
        verify(employeeCompOffService, times(1)).deleteById((long) 1);
    }
}