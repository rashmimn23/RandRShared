package main.controller;

import main.bean.Nomination;
import main.service.NominationService;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NominationControllerTest {

    @InjectMocks
    private NominationController nominationController;

    @Mock
    private NominationService nominationService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    public void tearDown() {
    }

    private Nomination getMockNomination() {
        Nomination nomination = new Nomination((long) 1, 1234567, 9876543, "Client_Appreciation", "Approved", 400);
        return nomination;
    }

    @Test
    public void getAll() {
        Mockito.when(nominationService.findAll()).thenReturn(Arrays.asList(getMockNomination()));
        List<Nomination> nominationList = nominationController.getAll();
        assertTrue(!CollectionUtils.isEmpty(nominationList));
    }

    @Test
    public void getByNomineeId() {
        Mockito.when(nominationService.getByNomineeId(1234567)).thenReturn(Arrays.asList(getMockNomination()));
        List<Nomination> nominationList = nominationController.getByNomineeId(1234567);
        assertTrue(!CollectionUtils.isEmpty(nominationList));
    }

    @Test
    public void getByManagerId() {
        Mockito.when(nominationService.getByManagerId(9876543)).thenReturn(Arrays.asList(getMockNomination()));
        List<Nomination> nominationList = nominationController.getByManagerId(9876543);
        assertTrue(!CollectionUtils.isEmpty(nominationList));
    }

    @Test
    public void update() {
        Nomination mockNomination= getMockNomination();
        Mockito.when(nominationService.update(any(Nomination.class))).thenReturn(mockNomination);
        Nomination response =  nominationController.update(mockNomination);
        Assert.assertEquals(mockNomination.getNomineeId(), response.getNomineeId());
    }

    @Test
    public void saveNomination() {
        Nomination mockNomination= getMockNomination();
        Mockito.when(nominationService.saveNomination(any(Nomination.class))).thenReturn(mockNomination);
        Nomination nomination = nominationController.saveNomination(mockNomination);
        assert (nomination.getNomineeId() == 1234567);
    }

    @Test
    public void saveExcelNomination() {
        MultipartFile excelDatafile=null;
        nominationController.saveExcelNomination(excelDatafile ,"Client_Appreciation");
        verify(nominationService, times(1)).saveExcelNomination(excelDatafile,"Client_Appreciation");
    }

    @Test
    public void delete() {
        nominationController.delete((long) 1234567);
        verify(nominationService, times(1)).delete((long) 1234567);
    }

    @Test
    public void statusUpdate() {
        nominationController.statusUpdate((long) 1, "Client_Appreciation", "Approved");
        verify(nominationService, times(1)).statusUpdate((long) 1, "Client_Appreciation", "Approved");

    }
}