package main.service;

import main.bean.EmployeeCompOff;
import main.reports.CompOffExceptionDownload;
import main.repository.EmployeeCompOffRepository;
import main.util.ConsolidatedCompOffExcelReader;
import main.util.UpdateEmployeeCompOff;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeCompOffServiceTest {
    @InjectMocks
    private EmployeeCompOffService employeeCompOffService;
    @Mock
    private EmployeeCompOffRepository employeeCompOffRepository;
    @Mock
    private ConsolidatedCompOffExcelReader consolidatedCompOffExcelReader;
    @Mock
    private UpdateEmployeeCompOff updateEmployeeCompOff;
    @Mock
    private CompOffExceptionDownload compOffExceptionDownload;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() throws Exception {
    }

    private EmployeeCompOff mockEmployeeCompOff() {
        EmployeeCompOff compOff = new EmployeeCompOff();
        compOff.setEmpId( 1234567 );
        compOff.setException( "Yes" );
        return compOff;
    }

    @Test
    public void readCompOffExcel() {
        MultipartFile file = null;
        Mockito.when( consolidatedCompOffExcelReader.readExcelCompOff( "January", 2020 , file, file ) ).thenReturn( Arrays.asList( mockEmployeeCompOff() ) );
        List<EmployeeCompOff> response = employeeCompOffService.readCompOffExcel( "January", 2020, file, file );
        assert (response.get( 0 ).getEmpId() == 1234567);
    }

    @Test
    public void readCompOffExcelFailure() {
        MultipartFile file = null;
        Mockito.when( consolidatedCompOffExcelReader.readExcelCompOff( "January", 2020 , file, file ) ).thenThrow( Exception.class );

        List<EmployeeCompOff> employeeCompOffs=employeeCompOffService.readCompOffExcel( "January", 2020, file, file );
        Assert.assertNull(employeeCompOffs);
    }

    @Test
    public void save() {
        EmployeeCompOff mockEmployeeCompOff = mockEmployeeCompOff();
        Mockito.when( employeeCompOffRepository.save( any( EmployeeCompOff.class ) ) ).thenReturn( mockEmployeeCompOff );
        EmployeeCompOff response = employeeCompOffService.save( mockEmployeeCompOff );
        assert (response.getEmpId() == 1234567);
    }

    @Test
    public void saveFailure() {
        EmployeeCompOff mockEmployeeCompOff = mockEmployeeCompOff();
        Mockito.when( employeeCompOffRepository.save( any( EmployeeCompOff.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeCompOffService.save( mockEmployeeCompOff ));
    }

    @Test
    public void getAll() {
        List<EmployeeCompOff> mockEmployeeCompOffList = Arrays.asList( mockEmployeeCompOff() );
        Mockito.when( employeeCompOffRepository.findAll() ).thenReturn( mockEmployeeCompOffList );
        List<EmployeeCompOff> response = employeeCompOffService.getAll();
        assertTrue( !CollectionUtils.isEmpty( mockEmployeeCompOffList ) );
    }

    @Test
    public void getAllFailure() {
        List<EmployeeCompOff> mockEmployeeCompOffList = Arrays.asList( mockEmployeeCompOff() );
        Mockito.when( employeeCompOffRepository.findAll() ).thenThrow( Exception.class );
        Assert.assertNull(employeeCompOffService.getAll());
    }

    @Test
    public void update() {
        EmployeeCompOff mockEmployeeCompOff = mockEmployeeCompOff();
        Mockito.when( employeeCompOffRepository.save( any( EmployeeCompOff.class ) ) ).thenReturn( mockEmployeeCompOff );
        EmployeeCompOff response = employeeCompOffService.update( mockEmployeeCompOff );
        assert (response.getEmpId() == 1234567);
    }

    @Test
    public void updateFailure() {
        EmployeeCompOff mockEmployeeCompOff = mockEmployeeCompOff();
        Mockito.when( employeeCompOffRepository.save( any( EmployeeCompOff.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeCompOffService.update( mockEmployeeCompOff ));
    }

    @Test
    public void updateCompOffList() {
        Mockito.when( updateEmployeeCompOff.updateEmployeeCompOff( Arrays.asList( any( EmployeeCompOff.class ) ) ) ).thenReturn( "Yes" );
        String response = employeeCompOffService.updateCompOffList( Arrays.asList( mockEmployeeCompOff() ) );
        assert (response == "Yes");
    }

    @Test
    public void updateCompOffListFailure() {
        Mockito.when( updateEmployeeCompOff.updateEmployeeCompOff( Arrays.asList( any( EmployeeCompOff.class ) ) ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeCompOffService.updateCompOffList( Arrays.asList( mockEmployeeCompOff() ) ));
    }

    @Test
    public void deleteByEmpId() {
        employeeCompOffService.deleteByEmpId( 1234567 );
        verify( employeeCompOffRepository, times( 1 ) ).deleteByEmpId( 1234567 );
    }

    @Test
    public void deleteById() {
        employeeCompOffService.deleteById( (long) 1 );
        verify( employeeCompOffRepository, times( 1 ) ).deleteById( (long) 1 );
    }

    @Test
    public void downloadCompoffException() {
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( compOffExceptionDownload.compOffExceptionDownload( anyString(), anyInt() ) ).thenReturn( mockXssfWorkbook );
        XSSFWorkbook response = employeeCompOffService.downloadCompoffException( "January", 2020 );
        assertTrue( !isEmpty( response ) );
    }

    @Test
    public void downloadCompoffExceptionFailure() {
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( compOffExceptionDownload.compOffExceptionDownload( anyString(), anyInt() ) ).thenThrow( Exception.class );
        Assert.assertNull( employeeCompOffService.downloadCompoffException( "January", 2020 ));
    }
}