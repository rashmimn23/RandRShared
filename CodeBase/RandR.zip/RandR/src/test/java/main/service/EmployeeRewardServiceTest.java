package main.service;

import main.bean.EmployeeReward;
import main.reports.WeekendDetailsDownload;
import main.repository.EmployeeRewardRepository;
import main.util.CalculatePoints;
import main.util.WeekendExcelReader;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeRewardServiceTest {
    @InjectMocks
    private EmployeeRewardService employeeRewardService;

    @Mock
    private EmployeeRewardRepository employeeRewardRepository;
    @Mock
    private WeekendExcelReader weekendExcelReader;
    @Mock
    private WeekendDetailsDownload weekendDetailsDownload;
    @Mock
    private CalculatePoints calculatePoints;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private EmployeeReward mockEmployeeReward() {
        EmployeeReward employeeReward = new EmployeeReward();
        employeeReward.setEmpId( 1234567 );
        employeeReward.setEmpName( "Aakash" );
        employeeReward.setManagerId( 9876543 );
        employeeReward.setNoOfPoints( 500 );
        employeeReward.setRewardType( "Interview_Telephonic" );
        employeeReward.setNoOfInterviews( 5 );
        return employeeReward;
    }

    private List<EmployeeReward> mockEmployeeRewardList() {
        List<EmployeeReward> employeeRewardList = new ArrayList<>();
        employeeRewardList.add( mockEmployeeReward() );
        employeeRewardList.add( mockEmployeeReward() );
        employeeRewardList.get( 0 ).setEmpId( 4567891 );
        return employeeRewardList;
    }

    @Test
    public void save() {
        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        Mockito.when( employeeRewardRepository.save( any( EmployeeReward.class ) ) ).thenReturn( mockEmployeeReward() );
        EmployeeReward response = employeeRewardService.save( mockEmployeeReward );
        assert (response.getEmpId() == 1234567);
    }

    @Test
    public void saveFailure() {
        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        Mockito.when( employeeRewardRepository.save( any( EmployeeReward.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull( employeeRewardService.save( mockEmployeeReward ) );
    }

    @Test
    public void findAll() {
        Mockito.when( employeeRewardRepository.findAll() ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardService.findAll();
        assert (response.get( 0 ).getEmpId() == 4567891);
    }

    @Test
    public void findAllFailure() {
        Mockito.when( employeeRewardRepository.findAll() ).thenThrow( Exception.class );
        Assert.assertNull( employeeRewardService.findAll() );
    }

    @Test
    public void getId() {
        Mockito.when( employeeRewardRepository.findByEmpId( anyInt() ) ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardService.getId( 1234567 );
        assert (response.get( 0 ).getEmpName().equals( "Aakash" ));
    }

    @Test
    public void getIdFailure() {
        Mockito.when( employeeRewardRepository.findByEmpId( anyInt() ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeRewardService.getId( 1234567 ));
    }

    @Test
    public void getByManagerId() {
        Mockito.when( employeeRewardRepository.findByManagerId( anyInt() ) ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardService.getByManagerId( 1234567 );
        assert (response.get( 0 ).getManagerId() == 9876543);
    }

    @Test
    public void getByManagerIdFailure() {
        Mockito.when( employeeRewardRepository.findByManagerId( anyInt() ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeRewardService.getByManagerId( 1234567 ));
    }

    @Test
    public void update() {

        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        Mockito.when( calculatePoints.calculateTotalPoints( anyString(), anyInt() ) ).thenReturn( 10 );
        Mockito.when( employeeRewardRepository.save( any( EmployeeReward.class ) ) ).thenReturn( mockEmployeeReward );
        EmployeeReward response = employeeRewardService.update( mockEmployeeReward );
        assert (response.getEmpName()).equals( "Aakash" );
        verify( calculatePoints, times( 1 ) ).calculateTotalPoints( anyString(), anyInt() );
    }

    @Test
    public void updateFailure() {

        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        Mockito.when( calculatePoints.calculateTotalPoints( anyString(), anyInt() ) ).thenReturn( 10 );
        Mockito.when( employeeRewardRepository.save( any( EmployeeReward.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeRewardService.update( mockEmployeeReward ));
    }

    @Test
    public void delete() {
        employeeRewardService.delete( (long) 1 );
        verify( employeeRewardRepository, times( 1 ) ).deleteById( (long) 1 );
    }

    @Test
    public void statusUpdate() {
        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        employeeRewardService.statusUpdate( idList, "Approved" );
        verify( employeeRewardRepository, times( 2 ) ).updateStatus( anyLong(), anyString() );
    }

    @Test
    public void statusUpdateFailure() throws Exception{
/*        EmployeeReward mockEmployeeReward = mockEmployeeReward();
        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        employeeRewardService.statusUpdate( idList, "Approved" );
        verify( employeeRewardRepository, times( 2 ) ).updateStatus( anyLong(), anyString() );*/
    }


    @Test
    public void getById() {
        Mockito.when( employeeRewardRepository.findById( anyLong() ) ).thenReturn( Optional.of( mockEmployeeReward() ) );
        Optional<EmployeeReward> response = employeeRewardService.getById( (long) 1 );
        assert (response.isPresent());
    }

    @Test
    public void getByIdFailure() {
        Mockito.when( employeeRewardRepository.findById( anyLong() ) ).thenThrow( Exception.class );
        Assert.assertNull( employeeRewardService.getById( (long) 1 ));
    }

    @Test
    public void readExcel() {
        MultipartFile file = null;
        Mockito.when( weekendExcelReader.read( file, 1234567 ) ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardService.readExcel( file, 1234567 );
        assert (response.get( 1 ).getEmpId() == 1234567);
    }

    @Test
    public void readExcelFailure() {
        MultipartFile file = null;
        Mockito.when( weekendExcelReader.read( file, 1234567 ) ).thenThrow( Exception.class );
        Assert.assertNull(employeeRewardService.readExcel( file, 1234567 ));
    }

    @Test
    public void updateAdvanceCompOff() {
        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        Mockito.when( employeeRewardRepository.findAll() ).thenReturn( mockEmployeeRewardList() );
        List<EmployeeReward> response = employeeRewardService.updateAdvanceCompOff( idList, "Yes" );

        assert (response.get( 0 ).getEmpId() == 4567891);
        verify( employeeRewardRepository, times( 1 ) ).updateAdvanceCompOffRepo( (long) 1, "Yes", 0 );
    }


    @Test
    public void updateAdvanceCompOffFailure() {
        List<Long> idList = new ArrayList<Long>( Arrays.asList( 1L, 2L ) );
        Mockito.when( employeeRewardRepository.findAll() ).thenThrow( Exception.class );
        Assert.assertNull(employeeRewardService.updateAdvanceCompOff( idList, "Yes" ));
    }

    @Test
    public void downloadWeekendDetails() {
        List<String> statusList = new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        Date startDate = new GregorianCalendar( 2020, Calendar.JANUARY, 11 ).getTime();
        Date endDate = new GregorianCalendar( 2020, Calendar.FEBRUARY, 11 ).getTime();
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( weekendDetailsDownload.downloadWeekendDetails( any( Date.class ), any( Date.class ), anyList() ) ).thenReturn( mockXssfWorkbook );
        XSSFWorkbook response = employeeRewardService.downloadWeekendDetails( startDate, endDate, statusList );
        assertTrue( !isEmpty( response ) );
    }

    @Test
    public void downloadWeekendDetailsFailure() {
        List<String> statusList = new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        Date startDate = new GregorianCalendar( 2020, Calendar.JANUARY, 11 ).getTime();
        Date endDate = new GregorianCalendar( 2020, Calendar.FEBRUARY, 11 ).getTime();
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( weekendDetailsDownload.downloadWeekendDetails( any( Date.class ), any( Date.class ), anyList() ) ).thenThrow( Exception.class );
        XSSFWorkbook response = employeeRewardService.downloadWeekendDetails( startDate, endDate, statusList );
        assertTrue( isEmpty( response ) );
    }
}