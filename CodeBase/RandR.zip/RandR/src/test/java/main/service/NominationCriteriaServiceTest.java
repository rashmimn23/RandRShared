package main.service;

import main.bean.NominationCriteria;
import main.repository.NominationCriteriaRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NominationCriteriaServiceTest {
    @InjectMocks
    private  NominationCriteriaService nominationCriteriaService;
    @Mock
    private NominationCriteriaRepository nominationCriteriaRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private NominationCriteria getMockNominationCriteria() {
        NominationCriteria mockNominationCriteria = new NominationCriteria( 1, "Client_Appreciation", "Team Size" );
        return mockNominationCriteria;
    }

    @Test
    public void save() {
        NominationCriteria mockNominationCriteria=getMockNominationCriteria();
        Mockito.when( nominationCriteriaRepository.save( any( NominationCriteria.class )) ).thenReturn( mockNominationCriteria );

        NominationCriteria nominationCriteria = nominationCriteriaService.save( mockNominationCriteria);
        assert (nominationCriteria.getCriteriaId() == 1);
    }

    @Test
    public void findAll() {
        Mockito.when( nominationCriteriaRepository.findAll() ).thenReturn( Arrays.asList( getMockNominationCriteria() ) );
        List<NominationCriteria> nominationCriteriaList = nominationCriteriaService.findAll();
        assertTrue( !CollectionUtils.isEmpty( nominationCriteriaList ) );
    }

    @Test
    public void getId() {
        Mockito.when( nominationCriteriaRepository.findByRewardType( anyString() )).thenReturn( Arrays.asList( getMockNominationCriteria() ) );

        List<NominationCriteria> nominationCriteriaList= nominationCriteriaService.getId( "Client_Appreciation" );
        assert (nominationCriteriaList.size() == 1);
    }

    @Test
    public void getOnlyCriteria() {
        Mockito.when( nominationCriteriaRepository.getOnlyCriteria( anyString() )).thenReturn( Arrays.asList(anyString() ));

        List<String> criteriaList= nominationCriteriaService.getOnlyCriteria( "Client_Appreciation" );
        assert (criteriaList.size() == 1);
    }

    @Test
    public void update() {
        NominationCriteria mockNominationCriteria=getMockNominationCriteria();
        Mockito.when( nominationCriteriaRepository.save( any( NominationCriteria.class )) ).thenReturn( mockNominationCriteria );
        NominationCriteria nominationCriteria = nominationCriteriaService.update( mockNominationCriteria );
        assert (nominationCriteria.getCriteriaId() == 1);
    }

    @Test
    public void delete() {
        nominationCriteriaService.delete( 1 );
        verify(nominationCriteriaRepository, times(1)).deleteById(anyInt());
    }

    @Test
    public void deleteByRewardType() {
        nominationCriteriaService.deleteByRewardType( "Client_Appreciation" );
        verify(nominationCriteriaRepository, times(1)).deleteByRewardType(anyString());
    }
}