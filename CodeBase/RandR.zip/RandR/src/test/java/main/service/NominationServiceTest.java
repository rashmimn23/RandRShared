package main.service;

import main.bean.EmployeeCompOff;
import main.bean.Nomination;
import main.bean.NominationRemark;
import main.bean.PointsValue;
import main.reports.NominationDetailsDownload;
import main.repository.NominationRemarkRepository;
import main.repository.NominationRepository;
import main.util.NominationExcelReader;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NominationServiceTest {
    @InjectMocks
    private NominationService nominationService;
    @Mock
    private NominationRepository nominationRepository;
    @Mock
    private NominationRemarkRepository nominationRemarkRepository;
    @Mock
    private NominationExcelReader nominationExcelReader;
    @Mock
    private PointsValueService pointsValueService;
    @Mock
    private NominationDetailsDownload nominationDetailsDownload;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private Nomination getMockNomination() {
        Nomination nomination = new Nomination( (long) 1, 1234567, 9876543, "Client_Appreciation", "Approved", 400 );
       nomination.setNominationRemarkList( getMockNominationRemark() );
        return nomination;
    }

    private List<Nomination> getMockNominationList() {
        Nomination nomination = new Nomination( (long) 1, 1234567, 9876543, "Client_Appreciation", "Approved", 400 );
        Nomination nomination1 = new Nomination( (long) 2, 9876543, 8524561, "Innovation_Award", "Approved", 600 );

        List<Nomination> mockNominationList = new ArrayList<>();
        mockNominationList.add( nomination );
        mockNominationList.add( nomination1 );
        return mockNominationList;
    }

    private PointsValue getPointsValue() {
        PointsValue pointsValue = new PointsValue( 1, "Client_Appreciation", 100 );
        return pointsValue;
    }
    private List<NominationRemark> getMockNominationRemark(){
        List<NominationRemark> mockNominationRemarkList = new ArrayList<>();
        NominationRemark nominationRemark = new NominationRemark(1, (long)1, 1, "R and R reognition" );
        mockNominationRemarkList=Arrays.asList(nominationRemark);
        return mockNominationRemarkList;
    }

    @Test
    public void findAll() {
        Mockito.when( nominationRepository.findAll() ).thenReturn( getMockNominationList() );
        List<Nomination> nominationList = nominationService.findAll();
        assertTrue( !CollectionUtils.isEmpty( nominationList ) );
    }

    @Test
    public void findAllFailure() {
        Mockito.when( nominationRepository.findAll() ).thenThrow( Exception.class );
        Assert.assertNull( nominationService.findAll() );
    }

    @Test
    public void getByNomineeId() {
        Mockito.when( nominationRepository.findByNomineeId( anyInt() ) ).thenReturn( getMockNominationList() );
        List<Nomination> nominationList = nominationService.getByNomineeId( 1234567 );
        assertTrue( !CollectionUtils.isEmpty( nominationList ) );
    }

    @Test
    public void getByNomineeIdFailure() {
        Mockito.when( nominationRepository.findByNomineeId(  anyInt()  ) ).thenThrow( Exception.class );
        Assert.assertNull(nominationService.getByNomineeId(1234567 ));
    }

    @Test
    public void getByManagerId() {
        Mockito.when( nominationRepository.findByManagerId( anyInt() ) ).thenReturn( getMockNominationList() );
        List<Nomination> nominationList = nominationService.getByManagerId( 9876543 );
        assertTrue( !CollectionUtils.isEmpty( nominationList ) );
    }

    @Test
    public void getByManagerIdFailure() {
        Mockito.when( nominationRepository.findByManagerId( anyInt() ) ).thenThrow( Exception.class );
        Assert.assertNull(nominationService.getByManagerId( 9876543 ));
    }

    @Test
    public void update() {
        Nomination mockNomination = getMockNomination();
        Mockito.when( nominationRepository.save( any( Nomination.class ) ) ).thenReturn( mockNomination );
        Nomination response = nominationService.update( mockNomination );
        Assert.assertEquals( mockNomination.getNomineeId(), response.getNomineeId() );
    }

    @Test
    public void updateFailure() {
        Nomination mockNomination = getMockNomination();
        Mockito.when( nominationRepository.save( any( Nomination.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(nominationService.update( mockNomination ));
    }

    @Test
    public void saveNomination() {
        Nomination mockNomination = getMockNomination();
        Mockito.when( nominationRepository.save( any( Nomination.class ) ) ).thenReturn( mockNomination );
        Mockito.when( nominationRemarkRepository.saveAll( anyListOf( NominationRemark.class ) ) ).thenReturn( getMockNominationRemark() );
        Nomination nomination = nominationService.saveNomination( mockNomination );
        assert (nomination.getNomineeId() == 1234567);
    }

    @Test
    public void saveNominationFailure() {
        Nomination mockNomination = getMockNomination();
        Mockito.when( nominationRepository.save(  any( Nomination.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(nominationService.saveNomination( mockNomination ));
    }

    @Test
    public void saveExcelNomination() {
        MultipartFile excelDatafile = null;
        nominationService.saveExcelNomination( excelDatafile, "Client_Appreciation" );
        verify( nominationExcelReader, times( 1 ) ).read( (any( MultipartFile.class )), anyString() );
    }

    @Test
    public void delete() {
        nominationService.delete( (long) 1234567 );
        verify( nominationRemarkRepository, times( 1 ) ).deleteInRemark( (long) 1234567 );
        verify( nominationRepository, times( 1 ) ).deleteInNomination( (long) 1234567 );
    }

    @Test
    public void statusUpdate() {
        Mockito.when( pointsValueService.findByRewardType( anyString() )).thenReturn( getPointsValue() );
        nominationService.statusUpdate( (long) 1, "Client_Appreciation", "Approved" );
        verify( nominationRepository, times( 1 ) ).updateStatus( anyLong(), anyInt(), anyString() );
    }

    @Test
    public void statusUpdateRejected() {
        Mockito.when( pointsValueService.findByRewardType( anyString() )).thenReturn( null );
        nominationService.statusUpdate( (long) 1, "Client_Appreciation", "Rejected" );
        verify( nominationRepository, times( 1 ) ).updateStatus( anyLong(), anyInt(), anyString() );
    }

    @Test
    public void downloadNominaionDetails() {

        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        List<String > statusList=new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        Mockito.when( nominationDetailsDownload.downloadNominaionDetails( anyString(), anyInt(),anyListOf( String.class ) ) ).thenReturn( mockXssfWorkbook );
        XSSFWorkbook response = nominationService.downloadNominaionDetails( "Q4", 2019,statusList );
        assertTrue( !isEmpty( response ) );
    }

    @Test
    public void downloadCompoffExceptionFailure() {
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        List<String > statusList=new ArrayList<String>( Arrays.asList( "Approved", "Rejected" ) );
        Mockito.when(nominationDetailsDownload.downloadNominaionDetails( anyString(), anyInt()  ,anyListOf( String.class ))).thenThrow( Exception.class );
        Assert.assertNull( nominationService.downloadNominaionDetails( "Q4", 2019,statusList));
    }
}