package main.service;

import main.bean.EmployeeReward;
import main.bean.PointsValue;
import main.repository.PointsValueRepository;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PointsValueServiceTest {
    @InjectMocks
    private PointsValueService pointsValueService;
    @Mock
    private PointsValueRepository pointsValueRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private PointsValue getPointsValue() {
        PointsValue pointsValue = new PointsValue( 1, "Client_Appreciation", 100 );
        return pointsValue;
    }

    private List<PointsValue> getPointsValueList() {
        PointsValue pointsValue1 = new PointsValue( 1, "Client_Appreciation", 100 );
        PointsValue pointsValue2 = new PointsValue( 2, "Innovation_Award", 50 );
        List<PointsValue> pointsValueList = Arrays.asList( pointsValue1, pointsValue2 );
        return pointsValueList;
    }


    @Test
    public void save() {
        Mockito.when( pointsValueRepository.save( any( PointsValue.class )) ).thenReturn( getPointsValue() );
        PointsValue pointsValue = pointsValueService.save( getPointsValue() );
        assert (pointsValue.getRewardType() == "Client_Appreciation");
    }

    @Test
    public void saveFailure() {
        PointsValue pointsValueMock = getPointsValue();
        Mockito.when( pointsValueRepository.save( any( PointsValue.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull( pointsValueService.save( pointsValueMock ) );
    }

    @Test
    public void getAll() {
        Mockito.when( pointsValueRepository.findAll() ).thenReturn( getPointsValueList() );
        List<PointsValue> pointsValueList = pointsValueService.getAll();
        assertTrue( !CollectionUtils.isEmpty( pointsValueList ) );
        assertTrue( pointsValueList.size() == 2 );
    }

    @Test
    public void getAllFailure() {
        Mockito.when( pointsValueRepository.findAll() ).thenThrow( Exception.class );
        Assert.assertNull( pointsValueService.getAll() );
    }

    @Test
    public void findByRewardType() {
        Mockito.when( pointsValueRepository.findByRewardType( anyString() ) ).thenReturn( getPointsValue() );
        PointsValue pointsValue = pointsValueService.findByRewardType( "Client_Appreciation" );
        assert (pointsValue.getPoints() == 100);
    }

    @Test
    public void findByRewardTypeFailure() {
        Mockito.when( pointsValueRepository.findByRewardType( anyString() ) ).thenThrow( Exception.class );
        Assert.assertNull(pointsValueService.findByRewardType( "Client_Appreciation" ));
    }

    @Test
    public void update() {
        PointsValue pointsValueMock = getPointsValue();
        pointsValueMock.setPoints( 600 );
        Mockito.when( pointsValueRepository.save( any( PointsValue.class ) ) ).thenReturn( pointsValueMock );
        PointsValue pointsValue = pointsValueService.update( pointsValueMock );

        assert (pointsValue.getPoints() == 600);
    }

    @Test
    public void updateFailure() {

        PointsValue pointsValueMock = getPointsValue();
        Mockito.when( pointsValueRepository.save( any( PointsValue.class ) ) ).thenThrow( Exception.class );
        Assert.assertNull(pointsValueService.update( pointsValueMock ));
    }

    @Test
    public void delete() {

        pointsValueService.delete( 1 );
        verify( pointsValueRepository, times( 1 ) ).deleteById( 1 );
    }
}