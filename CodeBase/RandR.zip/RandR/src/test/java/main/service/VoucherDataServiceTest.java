package main.service;

import main.bean.VoucherData;
import main.reports.VoucherDataDownload;
import main.repository.VoucherDataRepository;
import main.util.ProcessQuarterlyNomination;
import main.util.ProcessQuarterlyReward;
import main.util.QuarterlyNomination;
import main.util.QuarterlyReward;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.apache.logging.log4j.core.util.Assert.isEmpty;
import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.*;

@RunWith(MockitoJUnitRunner.class)
public class VoucherDataServiceTest {
    @InjectMocks
    private VoucherDataService voucherDataService;
    @Mock
    private VoucherDataRepository voucherDataRepository;
    @Mock
    private QuarterlyNomination quarterlyNomination;
    @Mock
    private QuarterlyReward quarterlyReward;
    @Mock
    private ProcessQuarterlyNomination processQuarterlyNomination;
    @Mock
    private ProcessQuarterlyReward processQuarterlyReward;
    @Mock
    private VoucherDataDownload voucherDataDownload;

    @BeforeEach
    public  void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private List<VoucherData> getMockVoucherDataList() {
        VoucherData voucherData1 = new VoucherData(1234567, "Revati", 500, "Q4", 2020, "Client_Appreciation", "01-2020");
        VoucherData voucherData2 = new VoucherData(9876543, "Pranjal", 500, "Q4", 2020, "Innovation_Award", "02-2020");

        List<VoucherData> voucherDataList = Arrays.asList(voucherData1, voucherData2);
        return voucherDataList;
    }
    @Test
    public void getAll() {
        Mockito.when(voucherDataRepository.findAll()).thenReturn(getMockVoucherDataList());
        List<VoucherData> voucherDataList = voucherDataService.getAll();
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void getQuarterlyNomination() {
        Mockito.when(quarterlyNomination.quarterlyNomination(anyString(),  anyInt() ) ).thenReturn(getMockVoucherDataList());
        List<VoucherData> voucherDataList = voucherDataService.getQuarterlyNomination("Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void getQuarterlyReward() {
        Mockito.when(quarterlyReward.quarterlyReward(anyString(),  anyInt() )).thenReturn(getMockVoucherDataList());

        List<VoucherData> voucherDataList = voucherDataService.getQuarterlyReward("Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void processQuarterlyNomination() {
        List<VoucherData> mockVoucherDataList = getMockVoucherDataList();
        Mockito.when(processQuarterlyNomination.processQuarterlyNomination( Matchers.anyListOf( VoucherData.class ), anyString(),  anyInt())).thenReturn(mockVoucherDataList);
        List<VoucherData> voucherDataList = voucherDataService.processQuarterlyNomination(mockVoucherDataList, "Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void processQuarterlyReward() {
        List<VoucherData> mockVoucherDataList = getMockVoucherDataList();
        Mockito.when(processQuarterlyReward.processQuarterlyReward(Matchers.anyListOf( VoucherData.class ), anyString(),  anyInt())).thenReturn(mockVoucherDataList);
        List<VoucherData> voucherDataList = voucherDataService.processQuarterlyReward(mockVoucherDataList, "Q4", 2020);
        assertTrue(!CollectionUtils.isEmpty(voucherDataList));
    }

    @Test
    public void downloadQuarterlyVoucher() {
        XSSFWorkbook mockXssfWorkbook = new XSSFWorkbook();
        Mockito.when( voucherDataDownload.voucherDataDownload( anyString(), anyInt(),anyString() ) ).thenReturn( mockXssfWorkbook );
        XSSFWorkbook response = voucherDataService.downloadQuarterlyVoucher( "Q4", 2019, "Client_Appreciation" );
        assertTrue( !isEmpty( response ) );
    }
}