package main.service;

import main.bean.EmployeeRole;
import main.repository.EmployeeRoleRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeRoleServiceTest {
    @InjectMocks
    private EmployeeRoleService employeeRoleService;

    @Mock
    private EmployeeRoleRepository employeeRoleRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private EmployeeRole getMockEmployeeRole() {
        EmployeeRole employeeRole = new EmployeeRole( 194878, "Rashmi", "Lead", 194868, "rashmi123" );
        return employeeRole;
    }

    private List<EmployeeRole> getMockEmployeeRoleList() {
        EmployeeRole employeeRole1 = new EmployeeRole( 194878, "Rashmi", "Lead", 194868, "rashmi123" );
        EmployeeRole employeeRole2 = new EmployeeRole( 1234567, "Revati", "Employee", 194878, "revati123" );
        List<EmployeeRole> mockEmployeeRoleList = new ArrayList<>(  );
        mockEmployeeRoleList.add( employeeRole1 );
        mockEmployeeRoleList.add( employeeRole2 );
        return mockEmployeeRoleList;
    }

    @Test
    public void save() {
        EmployeeRole mockEmployeeRole = getMockEmployeeRole();
        Mockito.when( employeeRoleRepository.save( any( EmployeeRole.class ) ) ).thenReturn( mockEmployeeRole );
        EmployeeRole response = employeeRoleService.save( mockEmployeeRole );
        assert (response.getEmpId() == 194878);
    }

    @Test
    public void findAll() {
        Mockito.when( employeeRoleRepository.findAll() ).thenReturn( getMockEmployeeRoleList() );
        List<EmployeeRole> employeeRoleList = employeeRoleService.findAll();
        assertTrue( !CollectionUtils.isEmpty( employeeRoleList ) );
    }

    @Test
    public void findById() {
        Mockito.when( employeeRoleRepository.findById( 194878 ) ).thenReturn( Optional.of( getMockEmployeeRole() ) );
        Optional<EmployeeRole> employeeRole = employeeRoleService.findById( 194878 );
        assert (employeeRole.get().getEmpId() == 194878);
    }

    @Test
    public void update() {
        EmployeeRole mockEmployeeRole = getMockEmployeeRole();
        Mockito.when( employeeRoleRepository.save( any( EmployeeRole.class ) ) ).thenReturn( mockEmployeeRole );
        EmployeeRole response = employeeRoleService.update( mockEmployeeRole );
        assert (response.getEmpId() == 194878);
    }

    @Test
    public void getRole() {
        Mockito.when(employeeRoleService.findById(anyInt())).thenReturn(Optional.of(getMockEmployeeRole()));
        Optional<EmployeeRole> employee  = employeeRoleService.getRole(194878, "rashmi123");
        assert (employee.get().getEmpId() == 194878);
    }

    @Test
    public void delete() {
        employeeRoleService.delete(194878);
        verify(employeeRoleRepository, times(1)).deleteById(anyInt());
    }
}