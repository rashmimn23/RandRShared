package main.service;

import main.bean.NominationRemark;
import main.repository.NominationRemarkRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class NominationRemarkServiceTest {
    @InjectMocks
    private NominationRemarkService nominationRemarkService;
    @Mock
    private NominationRemarkRepository nominationRemarkRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks( this );
    }

    @AfterEach
    public void tearDown() {
    }

    private NominationRemark getMockNominationRemark() {
        NominationRemark mockNominationRemark = new NominationRemark( 1, (long)1, 1, "R and R reognition" );
        return mockNominationRemark;
    }
    @Test
    public void save() {
        NominationRemark mockNominationRemark =getMockNominationRemark();
        Mockito.when( nominationRemarkRepository.save( any(NominationRemark.class) )).thenReturn( mockNominationRemark );

        NominationRemark nominationRemark = nominationRemarkService.save( mockNominationRemark );
        assert (nominationRemark.getRemarkId() == 1);
    }

    @Test
    public void findAll() {
        Mockito.when( nominationRemarkRepository.findAll() ).thenReturn( Arrays.asList( getMockNominationRemark() ) );
        List<NominationRemark> nominationRemarkList = nominationRemarkService.findAll();
        assertTrue( !CollectionUtils.isEmpty( nominationRemarkList ) );
    }

    @Test
    public void getId() {
        Mockito.when( nominationRemarkRepository.findById( (long) 1 )).thenReturn( Optional.of(getMockNominationRemark()) );

        Optional<NominationRemark> nominationRemark = nominationRemarkService.getId( (long) 1);
        assert (nominationRemark.get().getRemark().equals( "R and R reognition"));
    }

    @Test
    public void update() {
        NominationRemark mockNominationRemark =getMockNominationRemark();
        Mockito.when( nominationRemarkRepository.save( any(NominationRemark.class)) ) .thenReturn( mockNominationRemark );

        NominationRemark nominationRemark = nominationRemarkService.update( mockNominationRemark );
        assert (nominationRemark.getRemarkId() == 1);
    }
}