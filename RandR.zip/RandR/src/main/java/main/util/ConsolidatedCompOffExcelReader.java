package main.util;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeProjectInfo;
import main.repository.EmployeeCompOffRepository;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
public class ConsolidatedCompOffExcelReader {

    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    @Autowired
    private ReadEmployeeCompOff readEmployeeCompOff;

    @Autowired
    private ReadEmployeeProjectDetails readEmployeeProjectDetails;

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    @Autowired
    private CompOffDate compOffDate;

    public List<EmployeeCompOff> readExcelCompOff(String month, Integer year, MultipartFile compOffFile, MultipartFile employeeProjectExcel) throws IOException, ParseException {

        //Read Employee CompOff Excel
        List<EmployeeCompOff> employeeCompOffList = readEmployeeCompOff.readCompOff(compOffFile);

        // Read Employee Project Detail Excel
        List<EmployeeProjectInfo> employeeProjectInfoList=readEmployeeProjectDetails.readEmployeeProjectDetails( employeeProjectExcel );

        List<Date> dates = compOffDate.getMonthList( month, year);


        Calendar calendar=compOffDate.getCalendarMonth( month,year );
        Integer calendarMonth=calendar.get(Calendar.MONTH)+1;

        for (EmployeeCompOff employeeCompOff : employeeCompOffList){

            employeeCompOff.setMonth( calendarMonth );
            employeeCompOff.setYear( year );

            int empId=employeeCompOff.getEmpId();

            Optional<EmployeeProjectInfo> employeeProjectInfo = null;
            employeeProjectInfo = employeeProjectInfoList.stream().filter( employeeProjectInfoData -> employeeProjectInfoData.getEmpId().equals(empId)).findFirst();
            if (employeeProjectInfo.isPresent()){

                employeeCompOff.setLob( employeeProjectInfo.get().getLob());
                employeeCompOff.setProjectId(employeeProjectInfo.get().getProjectId() );
                employeeCompOff.setProjectName(employeeProjectInfo.get().getProjectName());
                employeeCompOff.setLocation( employeeProjectInfo.get(). getLocation());

                employeeCompOff.setDeliveryManager( employeeProjectInfo.get().getDeliveryManager() );

                List<Date> dateList= employeeRewardRepository.getQuarterlyDateList(employeeCompOff.getEmpId(), dates.get(0), dates.get(1));
                //employeeCompOff.setPartOfWeeekendInterview();
            }
        }
        employeeCompOffRepository.saveAll( employeeCompOffList );
        return employeeCompOffList;
    }
}