package main.util;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeReward;
import main.repository.EmployeeCompOffRepository;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UpdateEmployeeCompOff {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;
    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    public String updateEmployeeCompOff(List<EmployeeCompOff> employeeCompOffList) {

        String exceptionStatus = null;
        for (EmployeeCompOff employeeCompOff : employeeCompOffList) {
            EmployeeReward employeeReward = employeeRewardRepository.getStatus( employeeCompOff.getEmpId(), employeeCompOff.getDateOfInterviewWork() );
            if (employeeReward != null) {
                if (employeeReward.getStatus().equals( "VoucherAlloted" )) {
                    employeeCompOff.setQuarterlyVoucherStatus( employeeReward.getStatus() );
                    employeeCompOff.setException( "Yes" );
                    exceptionStatus = "Yes";
                } else {
                    employeeCompOff.setException( "No" );
                    employeeReward.setStatus( "CompOffApplied" );
                    employeeReward.setNoOfPoints( 0 );
                    employeeRewardRepository.save( employeeReward );
                }
            } else {
                employeeCompOff.setException( "No" );
            }
        }
        employeeCompOffRepository.saveAll( employeeCompOffList );
        return exceptionStatus;
    }
}
