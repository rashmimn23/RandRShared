package main.util;

import main.bean.PointsValue;
import main.service.PointsValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Component
public class CalculatePoints {

    private static List<PointsValue> points;
    @Autowired
    private PointsValueService pointsValueService;

    private void getAllPoints() {
        points = pointsValueService.getAll();
    }

    public Integer calculateTotalPoints(String reward_type, Integer interview) {
        Integer point = 1;
        if (CollectionUtils.isEmpty(points)) {
            getAllPoints();
        }
        Optional<PointsValue> optionalPoints = points.stream().filter(pointData -> pointData.getRewardType().equals(reward_type)).findFirst();
        if (optionalPoints.isPresent()) {
            point = optionalPoints.get().getPoints();
        }

        if (interview != null) {
            point = point * interview;
        }
        return point;

    }


}
