package main.util;

import main.bean.EmployeeReward;
import main.bean.VoucherData;
import main.repository.EmployeeRewardRepository;
import main.repository.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class QuarterlyReward {

    @Autowired
    private CompOffDate compOffDate;

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    @Autowired
    private NominationRepository nominationRepository;

    public List<VoucherData> quarterlyReward(String quarter, Integer year) {

        List<VoucherData> voucherData = new ArrayList<VoucherData>();
        List<VoucherData> employeePoints = new ArrayList<VoucherData>();

        List<Date> dates = compOffDate.getQuarterList( quarter, year );

        List<EmployeeReward> employeeRewardList = employeeRewardRepository.getQuarterList( "Approved","No", dates.get( 0 ), dates.get( 1 ) );
        employeeRewardList.stream().forEach( empReward -> employeePoints.add( new VoucherData( empReward.getEmpId(), empReward.getEmpName(), empReward.getNoOfPoints(), quarter, year, "Weekend_Interview","" ) ) );
        employeePoints.stream().forEach( empPoint -> {
            if (!voucherData.contains( empPoint )) {
                voucherData.add( empPoint );
            } else {
                VoucherData existingEmpPoint = voucherData.get( voucherData.indexOf( empPoint ) );
                existingEmpPoint.setPoints( empPoint.getPoints() + existingEmpPoint.getPoints() );
            }
        } );
        return voucherData;
    }
}
