package main.util;

import main.bean.EmployeeReward;
import main.bean.Nomination;
import main.bean.VoucherData;
import main.repository.EmployeeRewardRepository;
import main.repository.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class QuarterlyNomination {

    @Autowired
    private CompOffDate compOffDate;

    @Autowired
    private NominationRepository nominationRepository;

    public List<VoucherData> quarterlyNomination(String quarter, Integer year) {

        List<VoucherData> voucherData = new ArrayList<VoucherData>();
        List<Date> dates = compOffDate.getQuarterList(quarter, year);
        List<Nomination> nominationList = nominationRepository.getQuarterList("Approved", dates.get(0), dates.get(1));
        nominationList.stream().forEach(nomination -> voucherData.add(new VoucherData(nomination.getNomineeId(), nomination.getNomineeName(), nomination.getPoints(), quarter, year, nomination.getRewardType(), nomination.getTerm())));

        return voucherData;
    }
}
