package main.util;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

@Component
public class DownloadExcel {

    public void downloadExcel(String excelFileName, XSSFWorkbook workbook, final HttpServletResponse response) throws IOException {
        response.setContentType( "application/vnd.ms-excel;charset=UTF-8" );
        String headerKey = "Content-Disposition";
        String headerValue = String.format( "attachment; filename=\"%s\"",
                excelFileName );
        response.setHeader( headerKey, headerValue );

        //The response is stored in an outputstream
        OutputStream out = response.getOutputStream();
        response.setContentType( "application/vnd.ms-excel" );
        ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
        workbook.write( baos2 );
        byte[] bytes = baos2.toByteArray();
        out.write( bytes );
        out.flush();
        out.close();
    }
}
