package main.repository;

import main.bean.NominationRemark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface NominationRemarkRepository extends JpaRepository<NominationRemark, Long> {

    @Modifying
    @Transactional
    @Query(value="DELETE FROM NominationRemark WHERE id = ?1")
    void deleteInRemark(Long id);

}
