package main.service;

import main.bean.NominationCriteria;
import main.repository.NominationCriteriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NominationCriteriaService {

    @Autowired
    private NominationCriteriaRepository nominationCriteriaRepository;

// To save

    public NominationCriteria save(NominationCriteria nominationCriteria) {
        return nominationCriteriaRepository.save( nominationCriteria );
    }

// retrieve all employeerole details

    public List<NominationCriteria> findAll() {
        return nominationCriteriaRepository.findAll();
    }

//    Get by an id

    public List<NominationCriteria> getId(String rewardType) {
        return nominationCriteriaRepository.findByRewardType( rewardType );
    }

    //    Get only List of id's of Question
    public List<String> getOnlyCriteria(String rewardType) {
        return nominationCriteriaRepository.getOnlyCriteria( rewardType );
    }

// to update

    public NominationCriteria update(NominationCriteria nominationCriteria) {
        return nominationCriteriaRepository.save( nominationCriteria );
    }

    //to delete criteria
    public void delete(Integer criteriaId) {
        nominationCriteriaRepository.deleteById( criteriaId );
    }

    //to delete criterias for specific reward type
    public void deleteByRewardType(String criteriaId) {
        nominationCriteriaRepository.deleteByRewardType( criteriaId );
    }
}
