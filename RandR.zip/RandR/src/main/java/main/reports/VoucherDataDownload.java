package main.reports;

import main.bean.VoucherData;
import main.repository.VoucherDataRepository;
import main.service.VoucherDataService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VoucherDataDownload {

    @Autowired
    private VoucherDataRepository voucherDataRepository;

    public XSSFWorkbook voucherDataDownload(String quarter, Integer year, String rewardType) {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet( "VoucherData" );
        XSSFRow row = null;
        row = sheet.createRow( 0 );

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor( IndexedColors.AQUA.getIndex() );
        Cell cell = row.createCell( 0 );
        cell.setCellValue( "Employee ID" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 1 );
        cell.setCellValue( "Employee Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 2 );
        cell.setCellValue( "Points" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 3 );
        cell.setCellValue( "Quarter" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 4 );
        cell.setCellValue( "Year" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 5 );
        cell.setCellValue( "AllotedDate" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 6 );
        cell.setCellValue( "RewardType" );
        cell.setCellStyle( headerCellStyle );

        if (!rewardType.equals( "Weekend_Interview" )) {
            cell = row.createCell( 7 );
            cell.setCellValue( "Term" );
            cell.setCellStyle( headerCellStyle );
        }

        List<VoucherData> voucherDataList =null;
        if(rewardType.equals( "Weekend_Interview" )) {
            voucherDataList= voucherDataRepository.getQuarterlyWeekendInterviewData( quarter, year, rewardType );
        }
        else {
            voucherDataList=voucherDataRepository.getQuarterlyNominationData( quarter, year, "Weekend_Interview" );
        }
        int rownum = 1;
        for (VoucherData voucherData : voucherDataList) {
            row = sheet.createRow( rownum++ );
            createList( workbook, voucherData, row, rewardType );
        }
        return workbook;
    }

    private static void createList(XSSFWorkbook workbook, VoucherData voucherData, XSSFRow row, String rewardType) // creating cells for each row
    {
        Cell cell = row.createCell( 0 );
        cell.setCellValue( voucherData.getEmpId() );

        cell = row.createCell( 1 );
        cell.setCellValue( voucherData.getEmpName() );

        cell = row.createCell( 2 );
        cell.setCellValue( voucherData.getPoints() );

        cell = row.createCell( 3 );
        cell.setCellValue( voucherData.getQuarter() );

        cell = row.createCell( 4 );
        cell.setCellValue( voucherData.getYear() );

        cell = row.createCell( 5 );
        cell.setCellValue( voucherData.getAllotedDate() );
        CreationHelper creationHelper = workbook.getCreationHelper();
        CellStyle style1 = workbook.createCellStyle();
        style1.setDataFormat( creationHelper.createDataFormat().getFormat(
                "yyyy-MM-dd" ) );
        cell.setCellStyle( style1 );

        cell = row.createCell( 6 );
        cell.setCellValue( voucherData.getRewardType() );
        if (!rewardType.equals( "Weekend_Interview" )) {
            cell = row.createCell( 7 );
            cell.setCellValue( voucherData.getTerm() );
        }
    }
}

