package main.bean;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "pointsvalue")
public class PointsValue {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "POINTS_ID")
    private Integer pointsId;
    @Column(name = "REWARD_TYPE")
    private String rewardType;
    @Column(name = "POINTS")
    private Integer points;
    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;
    @Column(name = "MODIFIED_BY")
    private Integer modifiedBy;

    public Integer getPointsId() {
        return pointsId;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}
