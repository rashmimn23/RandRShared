package main.bean;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "voucherdata")
public class VoucherData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "VOUCHER_ID")
    private Long voucherId;
    @Column(name = "EMP_ID ")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "POINTS")
    private Integer points;
    @Column(name = "QUARTER")
    private String quarter;
    @Column(name = "YEAR")
    private Integer year;
    @Column(name = "REWARD_TYPE")
    private String rewardType;
    @Column(name = "TERM")
    private String term;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd",timezone = "Asia/Kolkata")
    @Temporal(TemporalType.DATE)
    @Column(name = "ALLOTED_DATE")
    private Date allotedDate;

    public VoucherData() {
    }

    public VoucherData(Integer empId, String empName, Integer points, String quarter, Integer year, String rewardType, String term) {
        this.empId = empId;
        this.empName = empName;
        this.points = points;
        this.quarter = quarter;
        this.year = year;
        this.rewardType = rewardType;
        this.term = term;
     }

    public VoucherData(Integer empId, String empName, Integer points, String quarter, Integer year, String rewardType, String term, Date allotedDate) {
        this.empId = empId;
        this.empName = empName;
        this.points = points;
        this.quarter = quarter;
        this.year = year;
        this.rewardType = rewardType;
        this.term = term;
        this.allotedDate=allotedDate;
    }

    public Long getVoucherId() {
        return voucherId;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Date getAllotedDate() {
        return allotedDate;
    }

    public void setAllotedDate(Date allotedDate) {
        this.allotedDate = allotedDate;
    }

    public String getQuarter() {
        return quarter;
    }

    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VoucherData that = (VoucherData) o;
        return Objects.equals( empId, that.empId ) &&
                Objects.equals( empName, that.empName );
    }

    @Override
    public int hashCode() {
        return Objects.hash( empId, empName );
    }
}
