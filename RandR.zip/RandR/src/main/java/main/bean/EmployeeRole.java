package main.bean;

import javax.persistence.*;

@Entity
@Table(name = "employeerole")

public class EmployeeRole {

    @Id
    @Column(name = "EMP_ID")
    private Integer empId;

    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "EMP_ROLE")
    private String empRole;

    @Column(name = "MANAGER_ID")
    private Long managerId;

    @Column(name = "PASSWORD")
    private String password;



    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpRole() {
        return empRole;
    }

    public void setEmpRole(String empRole) {
        this.empRole = empRole;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

        @Override
    public String toString() {
        return "EmployeeRole [Employee Id= " + empId + ",Employee Name= " + empName + ",Employee Role= " + empRole + ",Manager Id= " + managerId + "]";
    }

}
