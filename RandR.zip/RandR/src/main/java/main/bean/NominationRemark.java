package main.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "nominationremark", catalog = "randr")
public class NominationRemark {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "REMARK_ID")
    private Integer remarkId;
    @Column(name = "ID")
    private Long id;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID", insertable = false, updatable = false)
    private Nomination nomination;
    @Column(name = "CRITERIA_ID")
    private Integer criteriaId;
  /*  @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    private NominationCriteria nominationcriteria;*/

    @Column(name = "REMARK")
    private String remark;

    //Getters and Setters and Constructor

    public Integer getRemarkId() {
        return remarkId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCriteriaId() {
        return criteriaId;
    }

    public void setCriteriaId(Integer criteriaId) {
        this.criteriaId = criteriaId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public NominationRemark() {
    }

    public Nomination getNomination() {
        return nomination;
    }

    public void setNomination(Nomination nomination) {
        this.nomination = nomination;
    }

   /* public NominationCriteria getNominationcriteria() {
       return nominationcriteria;
    }

    public void setNominationcriteria(NominationCriteria nominationcriteria) {
        this.nominationcriteria = nominationcriteria;
    }*/
}
