import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InnovationAwardComponent } from './innovation-award.component';

describe('InnovationAwardComponent', () => {
  let component: InnovationAwardComponent;
  let fixture: ComponentFixture<InnovationAwardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InnovationAwardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InnovationAwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
