import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { RestDataService } from '../services/rest-data.service' ;
import {Router} from '@angular/router';


@Component({
  selector: 'app-innovation-award',
  templateUrl: './innovation-award.component.html',
  styleUrls: ['./innovation-award.component.css']
})
export class InnovationAwardComponent implements OnInit {

  questionsList = [];
  commentsForm: FormGroup;
  constructor(private restDataService: RestDataService, private fb:FormBuilder,private router: Router) {}

  downloadFile(){
    let link = document.createElement("a");
    link.download = "Innovation_Award_Template.xlsx";
    link.href = "assets/Innovation_Award.xlsx";
    link.click();
}
  ngOnInit() {

    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    // console.log("Its In")
    this.restDataService.getQuestionsListRequest("Innovation_Award").subscribe((resp: any[])=>{
      this.questionsList = resp;
      // console.log(this.questionsList);
  });
  this.commentsForm = this.fb.group({
    nomineeName: '',
    nomineeId: '',
    managerName: '',
    managerId: '',
    nominatorName: '',
    nominatorid: '',
    lob: '',
    duration: '',
    rewardType: 'Innovation_Award',
    nominationRemarkList: this.fb.array([this.fb.group({remark:'',criteriaId:''})]),
  });
  }
  get questionComments() {
    
    return this.commentsForm.get("nominationRemarkList") as FormArray;
  }

  addComment()
  {
    this.questionComments.push(this.fb.group({remark:'',criteriaId:''}));
  }
  onSubmit() {
    this.restDataService.doNominationRequest(this.commentsForm.value).subscribe((response: any[])=>{
      console.log(response);
    });
    console.warn(this.commentsForm.value);
  }

  file: File;
  selectedFiles: FileList;
  currentFile: File;
  
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

upload() {
  this.file = this.selectedFiles.item(0);
    this.restDataService.uploadNominationFile(this.file,'Innovation_Award').subscribe((response: any[])=>{
      if(response)
      {
        alert("Upload Successfully");
      }
      else{
        alert("Not Uploaded Try Again...")
      }
  });    
}

}