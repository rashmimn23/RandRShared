import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-pmo-view',
  templateUrl: './pmo-view.component.html',
  styleUrls: ['./pmo-view.component.css']
})
export class PmoViewComponent implements OnInit {

  constructor(private router: Router) { }

  private loadComponent = 'nomination_pmo';
  private loadComponent1='weekend_report';
    loadMyChildComponent(reward_type: any){
      console.log(reward_type);
       this.loadComponent = reward_type;
    }
    loadMyChildComponent1(reward_type: any){
      console.log(reward_type);
       this.loadComponent1 = reward_type;
    }
  private loginStatus = '';
    logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }
    EmployeeName='';
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')!='PMO')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    else if(sessionStorage.getItem('employeeRole')=='PMO')
    {
      this.EmployeeName = sessionStorage.getItem('employeeName');
      this.loginStatus='true';}
  }

}
