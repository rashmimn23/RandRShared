import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmoViewComponent } from './pmo-view.component';

describe('PmoViewComponent', () => {
  let component: PmoViewComponent;
  let fixture: ComponentFixture<PmoViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmoViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmoViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
