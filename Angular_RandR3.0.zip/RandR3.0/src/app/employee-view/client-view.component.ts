import { Component, OnInit } from '@angular/core';
import {RestDataService } from '../services/rest-data.service';
import {Router} from '@angular/router'


@Component({
  selector: 'app-client-view',
  templateUrl: './client-view.component.html',
  styleUrls: ['./client-view.component.css']
})

export class ClientViewComponent implements OnInit {

  EmployeeName = '';
  constructor(private restDataService: RestDataService, private router: Router) { }
 
    private loadComponent = 'nomination_table';
    private loadComponent1= 'weekend_static_view';
    loadMyChildComponent(reward_type: any){
      console.log(reward_type);
       this.loadComponent = reward_type;
    }
    loadMyChildComponent1(reward_type: any){
      console.log(reward_type);
       this.loadComponent1 = reward_type;
    }

    private loginStatus = '';
    logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }


  ngOnInit() {

    if(sessionStorage.getItem('employeeRole')!='EMPLOYEE')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
   else if(sessionStorage.getItem('employeeRole')=='EMPLOYEE'){
    this.EmployeeName = sessionStorage.getItem('employeeName');
    this.loginStatus='true';
}
  }
}
  

