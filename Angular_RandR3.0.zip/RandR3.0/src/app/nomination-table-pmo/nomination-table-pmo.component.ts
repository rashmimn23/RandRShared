import { Component, OnInit } from '@angular/core';
import{NominationserviceService} from '../services/nominationservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nomination-table-pmo',
  templateUrl: './nomination-table-pmo.component.html',
  styleUrls: ['./nomination-table-pmo.component.css']
  
})
export class NominationTablePmoComponent implements OnInit {
  selectedRows: any;
  selectedRowsid: any;
  selectedRowsrt: any;
  arrselectedRowsid: [2];
  arrselectedRowsrt: [2];
  i:any;

  mapS = new Map<any, any>();
  constructor(private nominationservice:NominationserviceService,private router: Router) { }

  settings = {
  
   actions: {
    add: false,
    edit: false,
    delete: false,

   },
    pager:{
      display:true,
      perPage:15
      },
      selectMode: 'multi',
      columns: {
        
        nomineeName: {
          title: 'NOMINEE_NAME',
          filter: true,
          sort: false
        },
        nomineeId: {
          title: 'NOMINEE_ID',
          filter: true
        },
        managerName: {
          title: 'MANAGER_NAME',
          filter: true
        },
        managerId: {
          title: 'MANAGER_ID',
          filter: true
        },
        nominatorName: {
          title: 'NOMINATOR_NAME',
          filter: true
        },
        nominatorid: {
          title: 'NOMINATOR_ID',
          filter: true
        },
        lob: {
          title: 'LOB',
          filter: true
        },
        rewardType: {
          title: 'REWARD_TYPE',
          filter: true
        },
        nominationStatus: {
          title: 'NOMINATION_STATUS',
          filter: true
        },
        nominationDate: {
          title: 'NOMINATION_DATE',
          filter: true
        },
        pmoId: {
          title: 'PMO_ID',
          filter: true
        },

      },
  
      attr: {
        class: 'table table-bordered'
      },
  
      defaultStyle: true
      
    };
   
    Approve(event){
      console.log("Edit Event In Console");
      for(this.i=0;this.i<this.arrselectedRowsid.length;this.i++){
               this.nominationservice.statusUpdate(this.arrselectedRowsid[this.i],this.arrselectedRowsrt[this.i],'Approve').subscribe(resp=>{   this.nominationservice.getAll().subscribe(resp=>{
                this.data=resp;
              });
               });
            }
      }
      Reject(event){
          console.log("Edit Event In Console")
          for(this.i=0;this.i<this.arrselectedRowsid.length;this.i++){
                this.nominationservice.statusUpdate(this.arrselectedRowsid[this.i],this.arrselectedRowsrt[this.i],'Reject').subscribe(resp=>{  this.nominationservice.getAll().subscribe(resp=>{
                  this.data=resp;
                });
                });
              }
          }

        rowClicked(event){
          this.selectedRows= event.selected;
          this.arrselectedRowsid=this.selectedRows.map(row => row.id);
          this.arrselectedRowsrt=this.selectedRows.map(row => row.rewardType);
          }


    data:any;
    ngOnInit() {
      if(sessionStorage.getItem('employeeRole')==null)
      {
        alert("Please Login First");
        this.router.navigate(['/login-view']);
      }
      this.nominationservice.getAll().subscribe(resp=>{
        this.data=resp;
        console.log('>>getAll: ',resp);
      });
    
    }
}
