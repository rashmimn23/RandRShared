import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { __param } from 'tslib';
import { HttpHeaders } from '@angular/common/http';
import {environment} from '../../environments/environment';



@Injectable({
  providedIn: 'root'
})
export class RestDataService {

  private baseUrl = environment.baseUrl;
  // private readCompOffAPI = "http://localhost:8080/readCompOff";
  // private allEmployeeDetailsAPI = "http://localhost:8080/employeeRewards/all";
  // private loginInfoAPI = "http://localhost:8080/employeeRole/role";
  // private singleEmployeeDetailsAPI = "http://localhost:8080/employeeRewards/getByEmployeeId";
  // private allEmployeeByManagerIdAPI = "http://localhost:8080/employeeRewards/getByManagerId" ;
  // private getWeekendDetailsAPI = "http://localhost:8080/excelReader" ;
  // private getQuestionsListAPI = "http://localhost:8080/nominationCriteria/getById";
  // private doNominationAPI = "http://localhost:8080/nomination/saveNomination";
  // private doNominationByExcelAPI = "http://localhost:8080/nomination/saveExcelNomination";
  // private doCompoffConsolidationAPI = "http://localhost:8080/employeeCompOff/compOff";
  // private weekendReportAPI = "http://localhost:8080/reports/downloadWeekendInterviewDetails";
  // private nominationReportAPI = "http://localhost:8080/reports/downloadNominationDetails";
  // private getCompOffExceptionReportAPI = "http://localhost:8080/reports/downloadCompoffException";
  
  constructor(private httpClient: HttpClient) {
   }

  public compOffGetRequest(){
    return this.httpClient.get(this.baseUrl+"/readCompOff");
  }

  public allEmployeeDetailsRequest(){
    return this.httpClient.get(this.baseUrl+"/employeeRewards/all");
  }

  public singleEmployeeDetailsRequest(employeeId: any){
    return this.httpClient.get(this.baseUrl+"/employeeRewards/getByEmployeeId/"+employeeId);
  }

  public allEmployeeByManagerIdRequest(managerId: any){
    return this.httpClient.get(this.baseUrl+"/employeeRewards/getByManagerId/"+managerId);
  }

  public loginInfoRequest(employeeId: any , password: any){
    return this.httpClient.get(this.baseUrl+"/employeeRole/role" +"/"+employeeId+"/"+password);
  }

  public getWeekendDetailsRequest(){
    return this.httpClient.get(this.baseUrl+"/excelReader");
  }

  public getQuestionsListRequest(rewardType: any){
    return this.httpClient.get(this.baseUrl+"/nominationCriteria/getById/"+rewardType);
  }
  
  public doNominationRequest(nominationData: any):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'my-auth-token'
      })
    };
    return this.httpClient.post(this.baseUrl+"/nomination/saveNomination",nominationData,httpOptions);
  }

  public uploadNominationFile(file: File,RewardType: any): Observable<any> {
    const formdata: FormData = new FormData();
    formdata.append('file',file);
    formdata.append('REWARD_TYPE',RewardType);
    return this.httpClient.post(this.baseUrl+"/nomination/saveExcelNomination",formdata,{  
    reportProgress: true
  });
   }
   public uploadCompoffConsolidateFile(month,year,file1: File,file2: File): Observable<any> {
    const formdata: FormData = new FormData();
    formdata.append('compOffFile',file1);
    formdata.append('employeeProjectInfo',file2);
    return this.httpClient.post(this.baseUrl+"/employeeCompOff/compOff/"+month+"/"+year,formdata);
   }
  public uploadFile(file: File,EMP_ID: any): Observable<any> {
    
    const formdata: FormData = new FormData();
    formdata.append('file',file);
    formdata.append('EMP_ID',EMP_ID);
    return this.httpClient.post(this.baseUrl+"/excelReader",formdata,{  
    reportProgress: true
  });
   }
   public 

   public getWeekendReport(startDate:Date,endDate:Date,statusList:any)
   {
     return this.httpClient.post(this.baseUrl+"/reports/downloadWeekendInterviewDetails/"+startDate+"/"+endDate,statusList,{ responseType: 'blob' as 'blob' });

   }
   public getNominationReport(quarter,year,statusList:any)
   {
     return this.httpClient.post(this.baseUrl+"/reports/downloadNominationDetails/"+quarter+"/"+year,statusList,{ responseType: 'blob' as 'blob' });

   }
   public getCompOffExceptionReport(month,year)
   {
     return this.httpClient.get(this.baseUrl+"/reports/downloadCompoffException/"+month+"/"+year,{ responseType: 'blob' as 'blob' });
   }
}