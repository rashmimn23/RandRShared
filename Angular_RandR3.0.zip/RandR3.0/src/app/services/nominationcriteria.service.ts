import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Point } from '../admin-view/Point';
import {environment} from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};
@Injectable({
  providedIn: 'root'
})
export class NominationcriteriaService {
  private baseUrl = environment.baseUrl;
  httpOptions: any;
  constructor(private http: HttpClient) {  }
    getAll():Observable<any>{
   
      return this.http.get(this.baseUrl+"/nominationCriteria/all");
    }
    addPoint (point: Point): Observable<Point> {
      return this.http.post<Point>(this.baseUrl+"/nominationCriteria/save", point, httpOptions);
    }
    update(data){
   
    return this.http.put(`${this.baseUrl+"/nominationCriteria"}/update`,data);
   
   }
   deleteRow(data){
  
    return this.http.delete<any>(this.baseUrl+"/nominationCriteria/deleteByid/"+data);
 }
}
