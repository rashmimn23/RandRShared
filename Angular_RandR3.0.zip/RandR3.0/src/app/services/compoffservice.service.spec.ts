import { TestBed } from '@angular/core/testing';

import { CompoffserviceService } from './compoffservice.service';

describe('CompoffserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CompoffserviceService = TestBed.get(CompoffserviceService);
    expect(service).toBeTruthy();
  });
});
