import { TestBed } from '@angular/core/testing';

import { NominationcriteriaService } from './nominationcriteria.service';

describe('NominationcriteriaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NominationcriteriaService = TestBed.get(NominationcriteriaService);
    expect(service).toBeTruthy();
  });
});
