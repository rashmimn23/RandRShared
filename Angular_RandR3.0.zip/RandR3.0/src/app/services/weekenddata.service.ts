import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import {environment} from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};
@Injectable({
  providedIn: 'root'
})
export class WeekenddataService {
  private baseUrl = environment.baseUrl;
  httpOptions: any;
  
  constructor(private http: HttpClient) {}
  getAll():Observable<any>{
 
    return this.http.get(this.baseUrl+"/employeeRewards/all");
  }
  getbyId():Observable<any>{
    // sessionStorage.setItem('employeeId','2347303');
    
    return this.http.get(this.baseUrl+"/employeeRewards/getByEmployeeId/"+sessionStorage.getItem('employeeId') );
  }
  statusUpdate(selectedRowsIDs, status) {
  console.log(status);
   const formData: FormData = new FormData();
   formData.append('ID',selectedRowsIDs);
   formData.append('STATUS',status);
   console.log(formData);
   return this.http.put(`${this.baseUrl}/employeeRewards/statusUpdate`,formData);
   
      
  }
  UpdateAdvanceCompOff(selectedRowsIDs:any, status) {
      return this.http.put(this.baseUrl+"/employeeRewards/UpdateAdvanceCompOff/"+status,selectedRowsIDs);
        
    }
 
}
