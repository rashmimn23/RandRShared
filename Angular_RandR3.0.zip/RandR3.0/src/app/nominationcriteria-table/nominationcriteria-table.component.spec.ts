import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NominationcriteriaTableComponent } from './nominationcriteria-table.component';

describe('NominationcriteriaTableComponent', () => {
  let component: NominationcriteriaTableComponent;
  let fixture: ComponentFixture<NominationcriteriaTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NominationcriteriaTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NominationcriteriaTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
