import { Component, OnInit } from '@angular/core';
import{NominationcriteriaService} from '../services/nominationcriteria.service';
import {Router} from '@angular/router'

@Component({
  selector: 'app-nominationcriteria-table',
  templateUrl: './nominationcriteria-table.component.html',
  styleUrls: ['./nominationcriteria-table.component.css']
})
export class NominationcriteriaTableComponent implements OnInit {

  constructor(private nominationcriteria:NominationcriteriaService,private router:Router) { }
  settings = {
    edit:{editButtonContent:'EDIT',
    UpdateButtonContent:'SAVE',
    cancleButtonContenet:'CANCLE',
    confirmSave: true,
   },
   add: {
     inputClass: '',
     addButtonContent: 'Add New',
     createButtonContent: 'Create',
     cancelButtonContent: 'Cancel',
     confirmCreate: true,
 },
 delete: {
  deleteButtonContent: 'DELETE',
  cancelButtonContent: 'CANCEL',
  confirmDelete: true
  },
   action: {
  add: true,
  delete: true
   },
    pager:{
      display:true,
      perPage:15
      },
      columns: {
       
        rewardType: {
          title: 'RewardType',
          filter: true
        },
        criteria: {
          title: 'Criteria',
          filter: true
        },

      },
  
      attr: {
  
        class: 'table table-bordered'
  
      },
  
      defaultStyle: true
      
    };
    data: any;
    onSaveConfirm(event){
      console.log("Edit Event In Console")
      console.log(event);
      event.confirm.resolve();
      this.nominationcriteria.update(event.newData).subscribe(resp=>{   
      });}
    onCreateConfirm(event){
      console.log("Creat Event In Console")
      console.log(event);
      event.confirm.resolve();
      this.nominationcriteria.addPoint(event.newData).subscribe(resp=>{});
     
    }
    onDeleteConfirm(event) {
      console.log("Delete Event In Console")
      console.log(event.data.rewardType);
        this.nominationcriteria.deleteRow(event.data.criteriaId).subscribe(resp=>{ console.log(resp);
                  event.confirm.resolve(event.source.data);});
      
    }
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    this.nominationcriteria.getAll().subscribe(resp=>{
      this.data=resp;
      console.log('>>getAll: ',resp);
    });
  }

}
