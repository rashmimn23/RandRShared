import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutstandingFlmComponent } from './outstanding-flm.component';

describe('OutstandingFlmComponent', () => {
  let component: OutstandingFlmComponent;
  let fixture: ComponentFixture<OutstandingFlmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutstandingFlmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutstandingFlmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
