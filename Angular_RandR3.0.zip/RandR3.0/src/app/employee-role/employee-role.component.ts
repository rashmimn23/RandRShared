import { Component, OnInit } from '@angular/core';
import {LocalDataSource} from 'ng2-smart-table';
import { EmployeeRoleService } from './employee-role.service';
import { EmployeeRole } from './employee-role';

@Component({
  selector: 'app-employee-role',
  templateUrl: './employee-role.component.html' ,
  styleUrls: ['./employee-role.component.css']
})
export class EmployeeRoleComponent implements OnInit {  
  constructor(private service: EmployeeRoleService) {}

  settings = {
    edit:{editButtonContent:'EDIT',
   UpdateButtonContent:'SAVE',
   cancleButtonContenet:'CANCLE',
   confirmSave: true,
  },
  add: {
    inputClass: '',
    addButtonContent: 'Add New',
    createButtonContent: 'Create',
    cancelButtonContent: 'Cancel',
    confirmCreate: true,
},
  action: {
 add: true

  },

  delete: {
     deleteButtonContent: 'Delete',
     cancelButtonContent: 'Cancel',
    confirmDelete: true,
},
  actions: {
 add: true,
delete:true
  },
 

  pager:{
    display:true,
    perPage:15
    },
  
    columns: {
      empId: {
        title: 'Employee Id',
        filter: true
      },
      empName: {
        title: 'Employee Name',
        filter: true

      },
      empRole: {
        title: 'Employee Role',
        filter: true

      },
      password:{
        title: 'Employee Password',
        filter: true

      },
      managerId :{
        title: 'Manager ID',
        filter: true

      }
    },
  attr: {
    class: 'table table-bordered'
     //table-success 

  },
  defaultStyle:true
};
onEditConfirm($event){
  console.log("Edit Event In Console")
}
onSaveConfirm(event){
console.log("Edit Event In Console")
console.log(event);
event.confirm.resolve();
this.service.update(event.newData).subscribe(resp=>{   
});
 
}
data: any;

onCreateConfirm(event){
  console.log("Creat Event In Console")
  console.log(event);
  event.confirm.resolve();
  // this.service.add(event.newData).subscribe(resp=>{});
 
}
ondeleteConfirm(event)
{
  console.log("Delete Event In Console")
  console.log(event.data.empId);
  this.service.deleteRow(event.data.empId).subscribe(resp=>{console.log(resp);
      event.confirm.resolve(event.source.data);});
 
}


  ngOnInit() {
   this.service.getAll().subscribe(resp=>{
     this.data=resp;
     console.log('>>getAll: ',resp);
   });
     }
  }
 
