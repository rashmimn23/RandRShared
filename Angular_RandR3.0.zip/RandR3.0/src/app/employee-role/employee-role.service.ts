import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
 import { EmployeeRole } from './employee-role';
 import {Router} from '@angular/router';
 import {environment} from '../../environments/environment';

 const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})

export class EmployeeRoleService {
  private baseUrl = environment.baseUrl;
  httpOptions: any;


constructor(private http: HttpClient,private router: Router) {
 }

 ngOnInit(){
  if(sessionStorage.getItem('employeeRole')==null)
  {
    alert("Please Login First");
    this.router.navigate(['/login-view']);
  }
 }
  getAll():Observable<any>{
    return this.http.get(this.baseUrl+"/employeeRole/all");
  }
  add(emp: EmployeeRole):Observable<EmployeeRole> {
    return this.http.post<EmployeeRole>(this.baseUrl+"/employeeRole/save", emp, httpOptions);
  }

  update(data){
  return this.http.put(`${this.baseUrl}/employeeRole/update`,data);
 }
 deleteRow(data){
 return this.http.delete<any>(this.baseUrl+"/employeeRole/deleteByid/"+data);
 }
}