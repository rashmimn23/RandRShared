     export class EmployeeRole {
        emp_ID: Number;
        emp_NAME: String;
        emp_ROLE: String;
        password: Number;
        manager_ID: Number;
            }
            

