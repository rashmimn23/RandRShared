import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramQuarterComponent } from './program-quarter.component';

describe('ProgramQuarterComponent', () => {
  let component: ProgramQuarterComponent;
  let fixture: ComponentFixture<ProgramQuarterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramQuarterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramQuarterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
