import { Component, OnInit } from '@angular/core';
import{CompoffserviceService} from '../services/compoffservice.service';

@Component({
  selector: 'app-compoff-consolidation-manager',
  templateUrl: './compoff-consolidation-manager.component.html',
  styleUrls: ['./compoff-consolidation-manager.component.css']
})
export class CompoffConsolidationManagerComponent implements OnInit {

  
  selectedRows: any;
  selectedRowsid: any;
  selectedRowsrt: any;
  arrselectedRowsid: [2];
  arrselectedRowsrt: [2];
  constructor(private compoffservice:CompoffserviceService) { }
  settings = {
    edit:{editButtonContent:'EDIT',
   UpdateButtonContent:'SAVE',
   cancleButtonContenet:'CANCLE',
   confirmSave: true,
  },
  actions: {
  add: false,
  delete: false,
  // edit:false
   },
    pager:{
      display:true,
      perPage:15
      },
      selectMode: 'multi',
      columns: {

      compOffId: {
      title: 'CompOff Id',
      filter: true,
      editable:false
      },
      empId: {
      title: 'Employee Id',
      filter: true,
      editable:false
      },
      empName: {
      title: 'Employee Name',
      filter: true,
      editable:false
      },
      compOffStatus: {
      title: 'Status',
      filter: true,
      editable:false
      },
      absenseType: {
      title: 'Absence Type',
      filter: true,
      editable:false
      },
      startDate : {
      title: 'Start Date',
      filter: true,
      editable:false
      },
      endDate : {
      title: 'End Date',
      filter: true,
      editable:false
      },
      lob : {
      title: 'LOB',
      filter: true,
      editable:false
      },
      projectId : {
      title: 'Project Id',
      filter: true,
      editable:false
      },
      projectName : {
      title: 'Project Name',
      filter: true,
      editable:false
      },
      location : {
      title: 'Location',
      filter: true,
      editable:false
      },
      deliveryManager : {
      title: 'Delivery Manager',
      filter: true,
      editable:false
      },
      partOfWeeekendInterview : {
      title: 'Part Of Weekend Interview',
      filter: true,
      editable:false
      },
      quarterlyVoucherStatus : {
      title: 'Quarterly Voucher Status',
      filter: true,
      editable:false
      },

      dateOfInterviewWork : {
        title: 'Date Of Inter View Work;',
        filter: true,    
        },
      reason : {
      title: 'Reason',
      filter: true,
    
      },
      comment: {
      title: 'Comment',
      filter: true
      },
      exception: {
      title: 'Exception',
      filter: true
     },
      },
  
      attr: {
  
        class: 'table table-bordered'
  
      },
  
      defaultStyle: true
       
    };
    onSaveConfirm(event){
      console.log("Edit Event In Console")
      console.log(event);
      console.log(event.data.reason);
      event.confirm.resolve();
      if(event.data.reason!=null && event.data.reason!=null ){
      this.compoffservice.update(event.newData).subscribe(resp=>{ 
      });
    }else{
      console.log("cannot  update");
      alert("Please fill mandotory column");
    }
      }
data:any;
  ngOnInit() {
    this.compoffservice.getAll().subscribe(resp=>{
      this.data=resp;
      console.log('>>getAll: ',resp);
    });
  }

}
