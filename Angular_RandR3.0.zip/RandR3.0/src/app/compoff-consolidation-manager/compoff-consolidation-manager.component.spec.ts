import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompoffConsolidationManagerComponent } from './compoff-consolidation-manager.component';

describe('CompoffConsolidationManagerComponent', () => {
  let component: CompoffConsolidationManagerComponent;
  let fixture: ComponentFixture<CompoffConsolidationManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompoffConsolidationManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompoffConsolidationManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
