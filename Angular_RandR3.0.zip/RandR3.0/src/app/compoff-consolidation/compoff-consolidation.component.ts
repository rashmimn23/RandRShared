import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../services/rest-data.service' ;
import { FormGroup, FormControl } from '@angular/forms';
import {Router} from '@angular/router';


@Component({
  selector: 'app-compoff-consolidation',
  templateUrl: './compoff-consolidation.component.html',
  styleUrls: ['./compoff-consolidation.component.css']
})
export class CompoffConsolidationComponent implements OnInit {
  constructor(private restDataService: RestDataService,private router: Router) { }
 
  form = new FormGroup({

    month: new FormControl(''),
    year: new FormControl('')
  });

  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
  }
  file1: File;
  file2: File;
  selectedFile1: FileList;
  selectedFile2: FileList;
  currentFile: File;
  
  selectFile1(event) {
    this.selectedFile1 = event.target.files;
  }
  selectFile2(event) {
    this.selectedFile2 = event.target.files;
  }

  onSubmit()
  {
  this.file1 = this.selectedFile1.item(0);
  this.file2 = this.selectedFile2.item(0);  
  this.restDataService.uploadCompoffConsolidateFile(this.form.value.month,this.form.value.year,this.file1,this.file2).subscribe((response: any[])=>{
  if(response)
  {
    alert("Uploaded Succesfully");
  }
  });    
}
}
