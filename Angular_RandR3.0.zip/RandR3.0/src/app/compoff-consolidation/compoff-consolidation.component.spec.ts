import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompoffConsolidationComponent } from './compoff-consolidation.component';

describe('CompoffConsolidationComponent', () => {
  let component: CompoffConsolidationComponent;
  let fixture: ComponentFixture<CompoffConsolidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompoffConsolidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompoffConsolidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
