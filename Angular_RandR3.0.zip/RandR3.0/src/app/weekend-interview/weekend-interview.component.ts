import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../services/rest-data.service';
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import {Router} from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-weekend-interview',
  templateUrl: './weekend-interview.component.html',
  styleUrls: ['./weekend-interview.component.css']
})
export class WeekendInterviewComponent implements OnInit {
  file: File;
  EMP_ID: any;
  employees = [];
  constructor(private restDataService: RestDataService, private router: Router ) { }
 
    settings = {
    actions: {
   add: false,
   delete: false,
   edit: false
    },
    pager:{
      display:true,
      perPage:15
      },
     
    
    
      columns: {
        empName: {
          title: 'Employee Name',
          filter: true
        },
        empId: {
          title: 'Employee Id',
          filter: true
  
        },
        rewardType: {
          title: 'Type of Reward',
          filter: true
  
        },
        noOfInterviews:{
          title: 'No. of Interview',
          filter: true
  
        },
        dateOf :{
          title: 'Date',
          filter: true
  
        },
        managerId :{
          title: 'Manager Id',
          filter: true
  
        },

        advanceCompoff :{
          title: 'Advance CompOff',
          filter: true
  
        },
     
        noOfPoints :{
          title: 'No. of Points',
          filter: true
  
        },
     
        createdby :{
          title: 'Created By',
          filter: true
  
        },
        modifiedBy :{
          title: 'Modified By',
          filter: true
  
        },
     
        status :{
          title: 'Status',
          filter: true
  
        }
     
      },
    
    attr: {
      class: 'table table-bordered ' 
  
    },
    defaultStyle:true,
  
    };

  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
  }
  selectedFiles: FileList;
  currentFile: File;
  
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

upload() {
  
  this.file = this.selectedFiles.item(0);
  this.EMP_ID = sessionStorage.getItem('employeeId');
    this.restDataService.uploadFile(this.file,this.EMP_ID).pipe(
      catchError(this.handleError)
      ).subscribe((response: any[])=>{
  this.employees = response;
  if(response)
      {
        alert("Upload Successfully");
      }
      else if(!response){
        alert("Not Uploaded Try Again...")
      }
  });    
}
handleError(error: HttpErrorResponse){
  alert("Not Uploaded Try Again... Make sure no duplicate data is uploaded")
  return throwError(error);
  }

}
