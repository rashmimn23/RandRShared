import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-superuser-view',
  templateUrl: './superuser-view.component.html',
  styleUrls: ['./superuser-view.component.css']
})
export class SuperuserViewComponent implements OnInit {

  constructor(private router: Router) { }

  private loadComponent = 'rewards_points';
    loadMyChildComponent(reward_type: any){
      console.log(reward_type);
       this.loadComponent = reward_type;
    }
    private loginStatus = '';
    logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }
    EmployeeName='';
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')!='SUPERUSER')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    else if(sessionStorage.getItem('employeeRole')=='SUPERUSER')
    {
      this.EmployeeName = sessionStorage.getItem('employeeName');
      this.loginStatus='true';}
  }

}
