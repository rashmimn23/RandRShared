import { Component, OnInit } from '@angular/core';
import { Point } from '../admin-view/Point';
import{ServiceService} from '../services/service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-rewards-points-view',
  templateUrl: './rewards-points-view.component.html',
  styleUrls: ['./rewards-points-view.component.css']
})
export class RewardsPointsViewComponent implements OnInit {

  constructor(private service:ServiceService, private router: Router) { }

  settings = {

  edit:{editButtonContent:'EDIT',
   UpdateButtonContent:'SAVE',
   cancleButtonContenet:'CANCLE',
   confirmSave: true,
  },
  add: {
    inputClass: '',
    addButtonContent: 'ADD NEW',
    createButtonContent: 'CREATE',
    cancelButtonContent: 'CANCLE',
    confirmCreate: true,
},
delete: {
  deleteButtonContent: 'DELETE',
  cancelButtonContent: 'CANCEL',
  confirmDelete: true
  },
action: {
 add: true,
 delete: true

  },
  pager:{
    display:true,
    perPage:15
    },
    columns: {
      rewardType: {
        title: 'RewardType',
        filter: true
      },
      points: {
        title: 'Points',
        filter: false
      }

    },

    attr: {

      class: 'table table-bordered'

    },

    defaultStyle: true
    
  };
  onSaveConfirm(event){
  event.confirm.resolve();
  this.service.update(event.newData).subscribe(resp=>{   
  });

  }
  onDeleteConfirm(event) {
      this.service.deletePoint(event.data.pointsId).subscribe(resp=>{ console.log(resp);
                event.confirm.resolve(event.source.data);});
    
  }
  data: any;
  
  onCreateConfirm(event){
    console.log("Creat Event In Console")
    console.log(event);
    event.confirm.resolve();
    this.service.addPoint(event.newData).subscribe(resp=>{});
   
  }
   ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
   this.service.getAll().subscribe(resp=>{
      this.data=resp;
      console.log('>>getAll: ',resp);
    });
  
  

}





}