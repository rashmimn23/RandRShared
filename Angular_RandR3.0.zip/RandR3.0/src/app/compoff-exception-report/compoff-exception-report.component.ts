import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { RestDataService } from '../services/rest-data.service';

@Component({
  selector: 'app-compoff-exception-report',
  templateUrl: './compoff-exception-report.component.html',
  styleUrls: ['./compoff-exception-report.component.css']
})
export class CompoffExceptionReportComponent implements OnInit {

  form = new FormGroup({

    month: new FormControl(''),
    year: new FormControl('')
  });
  constructor(private restDataService: RestDataService) { }

  ngOnInit() {
  }

  onSubmit()
  {
    const isIE = /*@cc_on!@*/false || !!document['documentMode'];
    const isChrome = !!window['chrome'];
    this.restDataService.getCompOffExceptionReport(this.form.value.month,this.form.value.year).subscribe(fileData=>{
      const blob: any = new Blob([fileData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      if (isIE) { // this code doesn't work for chrome
      console.log('Manage IE download>10');
      window.navigator.msSaveOrOpenBlob(blob,"CompOffException"+this.form.value.month+this.form.value.year+".xlsx");
  }
    if (isChrome) {  // this below code doesn't work for IE
    const link = document.createElement('a');
    if (link.download !== undefined) {
     const url = URL.createObjectURL(blob);
     link.setAttribute('href', url);
     link.setAttribute('download',"CompOffException"+this.form.value.month+this.form.value.year+".xlsx");
     link.setAttribute('target', '_self');
     document.body.appendChild(link);
     link.click();
     document.body.removeChild(link);
    }
  }
   else {
    window.navigator.msSaveOrOpenBlob(blob,"CompOffException"+this.form.value.month+this.form.value.year+".xlsx");
  }
    });
  }
}
