import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-hrview',
  templateUrl: './hrview.component.html',
  styleUrls: ['./hrview.component.css']
})
export class HrviewComponent implements OnInit {

  EmployeeName = '';
  constructor(private router: Router) { }

  private loadComponent = 'weekend_interview';
  loadMyChildComponent(reward_type: any){
    console.log(reward_type);
     this.loadComponent = reward_type;
  }
  private loginStatus = '';
  logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')!='HR')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    else if(sessionStorage.getItem('employeeRole')=='HR')
    {
      this.EmployeeName = sessionStorage.getItem('employeeName');
      this.loginStatus='true';}
  }

}
