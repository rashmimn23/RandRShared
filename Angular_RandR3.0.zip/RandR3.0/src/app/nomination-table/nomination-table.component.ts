import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Router, RouterModule } from '@angular/router';
import { NominationserviceService } from '../services/nominationservice.service';
import { RestDataService } from '../services/rest-data.service';

@Component({
  selector: 'app-nomination-table',
  templateUrl: './nomination-table.component.html',
  styleUrls: ['./nomination-table.component.css']
})
export class NominationTableComponent implements OnInit {

  modalRef: BsModalRef;
  constructor(private restDataService: RestDataService, private nominationservice: NominationserviceService, private router: Router, private modalService: BsModalService) { }

  settings = {
    edit: {
      editButtonContent: 'EDIT',
      UpdateButtonContent: 'SAVE',
      cancleButtonContenet: 'CANCLE',
      confirmSave: true,
    },
    add: {
      inputClass: '',
      addButtonContent: 'ADD NEW',
      createButtonContent: 'CREATE',
      cancelButtonContent: 'CANCLE',
      confirmCreate: true,
    },
    delete: {
      deleteButtonContent: 'DELETE',
      cancelButtonContent: 'CANCEL',
      confirmDelete: true
    },
    action: {
      add: true,
      delete: true
    },
    pager: {
      display: true,
      perPage: 15
    },
    actions: {
      custom: [
        {
          name: 'remark',
          title: 'Remark ',
        }
      ],
    },
    columns: {

      nomineeName: {
        title: 'NOMINEE_NAME',
        filter: true
      },
      nomineeId: {
        title: 'NOMINEE_ID',
        filter: true
      },
      managerName: {
        title: 'MANAGER_NAME',
        filter: true
      },
      managerId: {
        title: 'MANAGER_ID',
        filter: true
      },
      nominatorName: {
        title: 'NOMINATOR_NAME',
        filter: true
      },
      nominatorid: {
        title: 'NOMINATOR_ID',
        filter: true
      },
      lob: {
        title: 'LOB',
        filter: true
      },
      rewardType: {
        title: 'REWARD_TYPE',
        filter: true
      },
      nominationStatus: {
        title: 'NOMINATION_STATUS',
        filter: true
      },
      nominationDate: {
        title: 'NOMINATION_DATE',
        filter: true
      },
      pmoId: {
        title: 'PMO_ID',
        filter: true
      },


    },

    attr: {

      class: 'table table-bordered'

    },

    defaultStyle: true

  };


  onDeleteConfirm(event) {
    this.nominationservice.deleteRow(event.data.id).subscribe(resp => {
      // console.log(resp);
      event.confirm.resolve(event.source.data);
    });

  }

  data: any;
  remarkList: any;
  questionsList= Array();
  ngOnInit() {
    if (sessionStorage.getItem('employeeRole') == null) {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    this.nominationservice.getAll().subscribe(resp => {
      this.data = resp;
    });
  }
  remark(event, template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
    this.questionsList=[];
    for (let r of this.data) {
      if (r.id == event.data.id) {
        this.remarkList = r.nominationRemarkList;
        // console.log(this.remarkList);
        this.restDataService.getQuestionsListRequest(r.rewardType).subscribe((questions: any) => {
          console.log(questions);
          for (let re of this.remarkList) {
            for (let ques of questions) {
              if (re.criteriaId == ques.criteriaId ) {
                this.questionsList.push((ques.criteria + "-->" + re.remark));
              }
            }
          }
        });

      }
    }
  }


}
