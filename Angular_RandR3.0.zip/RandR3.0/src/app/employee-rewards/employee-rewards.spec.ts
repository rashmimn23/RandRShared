import { EmployeeRewards } from './employee-rewards';

describe('EmployeeRewards', () => {
  it('should create an instance', () => {
    expect(new EmployeeRewards()).toBeTruthy();
  });
});
