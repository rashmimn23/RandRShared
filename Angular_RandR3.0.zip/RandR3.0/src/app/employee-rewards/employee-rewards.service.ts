import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { EmployeeRewards } from './employee-rewards';
import {Router} from '@angular/router';
import {environment} from '../../environments/environment';

 const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})

export class EmployeeRewardsService {
  private baseUrl = environment.baseUrl;
  httpOptions: any;


constructor(private http: HttpClient,private router: Router) {}
 ngOnInit()
 {
  if(sessionStorage.getItem('employeeRole')==null)
  {
    alert("Please Login First");
    this.router.navigate(['/login-view']);
  }
 }
  getAll():Observable<any>{
    return this.http.get(this.baseUrl+"/employeeRewards/all");
  }
  add(emp: EmployeeRewards):Observable<EmployeeRewards> {
    return this.http.post<EmployeeRewards>(this.baseUrl+"/employeeRewards/save", emp, httpOptions);
  }

  update(data){
  return this.http.put(`${this.baseUrl}/employeeRewards/update`,data);
 }
 deleteRow(data){
  return this.http.delete<any>(this.baseUrl+"/employeeRewards/deleteByid/"+data);
  };
 }

