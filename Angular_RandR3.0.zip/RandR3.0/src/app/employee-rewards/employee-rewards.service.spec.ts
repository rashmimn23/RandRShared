import { TestBed } from '@angular/core/testing';

import { EmployeeRewardsService } from './employee-rewards.service';

describe('EmployeeRewardsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeRewardsService = TestBed.get(EmployeeRewardsService);
    expect(service).toBeTruthy();
  });
});
