import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekendDataApproveComponent } from './weekend-data-approve.component';

describe('WeekendDataApproveComponent', () => {
  let component: WeekendDataApproveComponent;
  let fixture: ComponentFixture<WeekendDataApproveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekendDataApproveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekendDataApproveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
