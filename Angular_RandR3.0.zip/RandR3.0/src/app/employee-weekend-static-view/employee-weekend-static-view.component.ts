import { Component, OnInit } from '@angular/core';
import { WeekenddataService } from '../services/weekenddata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-weekend-static-view',
  templateUrl: './employee-weekend-static-view.component.html',
  styleUrls: ['./employee-weekend-static-view.component.css']
})
export class EmployeeWeekendStaticViewComponent implements OnInit {

  selectedRows: any;
  selectedRowsid: any;
  arrselectedRowsid: [];
  i:any;
  constructor(private weekenddataservice:WeekenddataService,private router: Router ) { }
  settings = {
  
    actions: {
     add: false,
     edit: false,
     delete: false,
 
    },
     pager:{
       display:true,
       perPage:15
       },
       columns: {
         
         empId: {
           title: 'Emp_Id',
           filter: true,
           sort: false
         },
         empName: {
           title: 'Emp_Name',
           filter: true
         },
         rewardType: {
           title: 'MANAGER_NAME',
           filter: true
         },
         skill: {
           title: 'Skill',
           filter: true
         },
         location: {
           title: 'Location',
           filter: true
         },
         noOfInterviews: {
           title: 'No_Of_Interviews',
           filter: true
         },
         noOfPoints: {
           title: 'No_Of_Points',
           filter: true
         },
         dateOf: {
           title: 'Date_Of',
           filter: true
         },
         createdby: {
           title: 'Created_By',
           filter: true
         },
         modifiedBy: {
           title: 'Modified_By',
           filter: true
         },
         managerId: {
           title: 'Manager_Id',
           filter: true
         },
         advanceCompoff: {
           title: 'Advance_Compoff',
           filter: true
         },
         status : {
           title: 'Status',
           filter: true
         },
 
       },
   
       attr: {
         class: 'table table-bordered'
       },
   
       defaultStyle: true
       
     };
    data: any;
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    this.weekenddataservice.getbyId().subscribe(resp=>{
    this.data=resp;
      // console.log('>>getAll: ',this.data);
    });
  }

}
