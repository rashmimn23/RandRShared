import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
// import { LocalDataSource } from 'ng2-smart-table';


// import { viewClassName } from '@angular/compiler';
@Component({
  selector: 'app-admin-view',
  templateUrl: './admin-view.component.html',
  styleUrls: ['./admin-view.component.css']
})
export class AdminViewComponent implements OnInit {
  
  EmployeeName = '';
  constructor(private router: Router) { }

  private loadComponent = 'nominationcriteria_table';
    loadMyChildComponent(reward_type: any){
      console.log(reward_type);
       this.loadComponent = reward_type;
    }
  
    private loginStatus = '';
    logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }

   ngOnInit() {
    if(sessionStorage.getItem('employeeRole')!='ADMIN')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    else if(sessionStorage.getItem('employeeRole')=='ADMIN')
    { 
      this.EmployeeName = sessionStorage.getItem('employeeName');
      this.loginStatus='true';
  }
    };





}