export interface Point {
    rewardType: string;
    points: number;
    modifiedDate: Date;
    modifiedBy: number;
  }