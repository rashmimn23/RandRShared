import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { VoucherDataComponent } from './voucher-data.component';
import {environment} from '../../environments/environment';

const httpOptions = {
  
};
@Injectable({
  providedIn: 'root'
})
export class VoucherDataService {

  private baseUrl = environment.baseUrl;
    httpOptions: any;
  
  
  constructor(private http: HttpClient) {

   }
    getAll():Observable<any>{
      return this.http.get(this.baseUrl+"/voucherData/all");
    }
    add(emp: VoucherDataComponent):Observable<VoucherDataComponent> {
      return this.http.post<VoucherDataComponent>(this.baseUrl+"/voucherData/save", emp);
    }
  
    update(data){
    return this.http.put(`${this.baseUrl}/voucherData/update`,data);
   }
   deleteRow(data){
   return this.http.delete<any>(this.baseUrl+"/voucherData/deleteByid/"+data);
   }
   getQuarterlyNominationRequest(QUARTER:any,YEAR:any)
   {
     return this.http.get(this.baseUrl+'/voucherData/getQuarterlyNomination/'+QUARTER+'/'+YEAR);
   }
   getQuarterlyRewardRequest(QUARTER:any,YEAR:any)
   {
     return this.http.get(this.baseUrl+'/voucherData/getQuarterlyReward/'+QUARTER+'/'+YEAR);
   }
   downloadVoucherDataRequest(QUARTER:any,YEAR:any,REWARDTYPE:any)
   {
     return this.http.get(this.baseUrl+"/reports/downloadQuarterlyVoucher/"+QUARTER+"/"+YEAR+"/"+REWARDTYPE,{ responseType: 'blob' as 'blob' });
   }
   processVoucherDataRequest()
   {
     return this.http.get(this.baseUrl);
   }
  }