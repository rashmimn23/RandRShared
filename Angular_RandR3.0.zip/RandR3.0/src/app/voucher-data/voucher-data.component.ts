import { Component, OnInit } from '@angular/core';
import {VoucherDataService} from './voucher-data.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
@Component({

  selector: 'app-voucher-data',
  templateUrl: './voucher-data.component.html',
  styleUrls: ['./voucher-data.component.css']
})
export class VoucherDataComponent implements OnInit {
  constructor(private service: VoucherDataService,private router: Router) {}
  voucherForm = new FormGroup({
  
    quarter: new FormControl(''),
    year: new FormControl(''),
    rewardType: new FormControl('')
  });
  settings = {
    edit:{editButtonContent:'EDIT',
   UpdateButtonContent:'SAVE',
   cancleButtonContenet:'CANCLE',
   confirmSave: true,
  },
  add: {
    inputClass: '',
    addButtonContent: 'Add New',
    createButtonContent: 'Create',
    cancelButtonContent: 'Cancel',
    confirmCreate: true,
},
  actions: {
 add: false,
 edit: false,
 delete: false
  },
  pager:{
    display:true,
    perPage:15
    },
  
    columns: {
      empId: {
        title: 'Employee Id',
        filter: true
      },
      empName: {
        title: 'Employee Name',
        filter: true

      },
      points: {
        title: 'Points',
        filter: true

      },
      allotedDate:{
        title: 'Alloted Date',
        filter: true

      },
      quarter :{
        title: 'Quarter',
        filter: true

      },
      year :{
        title: 'Year',
        filter: true

      }
    },
  attr: {
    class: 'table table-bordered'

  },
  defaultStyle:true
};
onEditConfirm($event){
  console.log("Edit Event In Console")
}
onSaveConfirm(event){
console.log("Edit Event In Console")
console.log(event);
event.confirm.resolve();
this.service.update(event.newData).subscribe(resp=>{   
});
}
data: any;

onCreateConfirm(event){
  console.log("Creat Event In Console")
  console.log(event);
  event.confirm.resolve();
  this.service.add(event.newData).subscribe(resp=>{});
 
}
onSubmit(buttonType): void
{
  if(buttonType=='SubmitData'){
  if(this.voucherForm.value.rewardType=='Nomination')
  {
    this.service.getQuarterlyNominationRequest(this.voucherForm.value.quarter,this.voucherForm.value.year).subscribe(resp=>{
    this.data=resp;
  });
    console.log(this.data);
  }
  else if(this.voucherForm.value.rewardType=='Weekend_Interview')
  {
    this.service.getQuarterlyRewardRequest(this.voucherForm.value.quarter,this.voucherForm.value.year).subscribe(resp=>{
      this.data=resp;});
  }
}
else if(buttonType=='DownloadData')
{
//   const isIE = /*@cc_on!@*/false || !!document['documentMode'];
//   const isChrome = !!window['chrome'];
//   this.service.downloadVoucherDataRequest(this.voucherForm.value.quarter,this.voucherForm.value.year,this.voucherForm.value.rewardType).subscribe(fileData=>{
//     const blob: any = new Blob([fileData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
//     if (isIE) { // this code doesn't work for chrome
//     console.log('Manage IE download>10');
//     window.navigator.msSaveOrOpenBlob(blob,this.voucherForm.value.rewardType+".xlsx");
// } else if (isChrome) {  // this below code doesn't work for IE
//   const link = document.createElement('a');
//   if (link.download !== undefined) {
//    const url = URL.createObjectURL(blob);
//    link.setAttribute('href', url);
//    link.setAttribute('download',this.voucherForm.value.rewardType+".xlsx");
//    link.setAttribute('target', '_self');
//    document.body.appendChild(link);
//    link.click();
//    document.body.removeChild(link);
//   }
// } else {
//   window.navigator.msSaveOrOpenBlob(blob,this.voucherForm.value.rewardType+".xlsx");
// }
//   });
}
}


processData()
{
  // this.service.processVoucherDataRequest();
  alert("Sorry for the inconvenience,we are working on this...!");
}

  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }

     }
  }
 

