import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherDataComponent } from './voucher-data.component';

describe('VoucherDataComponent', () => {
  let component: VoucherDataComponent;
  let fixture: ComponentFixture<VoucherDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoucherDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoucherDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
