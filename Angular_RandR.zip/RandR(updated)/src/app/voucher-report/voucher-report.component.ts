import { Component, OnInit } from '@angular/core';
import {VoucherDataService} from '../voucher-data/voucher-data.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-voucher-report',
  templateUrl: './voucher-report.component.html',
  styleUrls: ['./voucher-report.component.css']
})
export class VoucherReportComponent implements OnInit {
  constructor(private service: VoucherDataService,private router: Router) {}
  voucherForm = new FormGroup({
  
    quarter: new FormControl(''),
    year: new FormControl(''),
    rewardType: new FormControl('')
  });


  onSubmit()
{
  const isIE = /*@cc_on!@*/false || !!document['documentMode'];
  const isChrome = !!window['chrome'];
  this.service.downloadVoucherDataRequest(this.voucherForm.value.quarter,this.voucherForm.value.year,this.voucherForm.value.rewardType).subscribe(fileData=>{
    const blob: any = new Blob([fileData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    if (isIE) { // this code doesn't work for chrome
    console.log('Manage IE download>10');
    window.navigator.msSaveOrOpenBlob(blob,this.voucherForm.value.rewardType+".xlsx");
}
  if (isChrome) {  // this below code doesn't work for IE
  const link = document.createElement('a');
  if (link.download !== undefined) {
   const url = URL.createObjectURL(blob);
   link.setAttribute('href', url);
   link.setAttribute('download',this.voucherForm.value.rewardType+".xlsx");
   link.setAttribute('target', '_self');
   document.body.appendChild(link);
   link.click();
   document.body.removeChild(link);
  }
}
 else {
  window.navigator.msSaveOrOpenBlob(blob,this.voucherForm.value.rewardType+".xlsx");
}
  });
}

  ngOnInit() {
  }

}
