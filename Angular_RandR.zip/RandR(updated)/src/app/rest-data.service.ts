import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { __param } from 'tslib';
import {HttpHeaders} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class RestDataService {

  private readCompOffAPI = "http://localhost:8080/readCompOff";
  private allEmployeeDetailsAPI = "http://localhost:8080/employeeRewards/all";
  private loginInfoAPI = "http://localhost:8080/employeeRole/role";
  private singleEmployeeDetailsAPI = "http://localhost:8080/employeeRewards/getByEmployeeId";
  private allEmployeeByManagerIdAPI = "http://localhost:8080/employeeRewards/getByManagerId" ;
  private getWeekendDetailsAPI = "http://localhost:8080/excelReader" ;
  private getQuestionsListAPI = "http://localhost:8080/nominationCriteria/getById";
  private doNominationAPI = "http://localhost:8080/nomination/saveNomination";
  private doNominationByExcelAPI = "http://localhost:8080/nomination/saveExcelNomination";
  private doCompoffConsolidationAPI = "http://localhost:8080/employeeCompOff/compOff";
  private weekendReportAPI = "http://localhost:8080/reports/downloadWeekendInterviewDetails";
  private nominationReportAPI = "http://localhost:8080/reports/downloadNominationDetails";
  private getCompOffExceptionReportAPI = "http://localhost:8080/reports/downloadCompoffException";

  
  constructor(private httpClient: HttpClient) {
   }

  public compOffGetRequest(){
    return this.httpClient.get(this.readCompOffAPI);
  }

  public allEmployeeDetailsRequest(){
    return this.httpClient.get(this.allEmployeeDetailsAPI);
  }

  public singleEmployeeDetailsRequest(employeeId: any){
    return this.httpClient.get(this.singleEmployeeDetailsAPI+"/"+employeeId);
  }

  public allEmployeeByManagerIdRequest(managerId: any){
    return this.httpClient.get(this.allEmployeeByManagerIdAPI+"/"+managerId);
  }

  public loginInfoRequest(employeeId: any , password: any){
    return this.httpClient.get(this.loginInfoAPI+"/"+employeeId+"/"+password);
  }

  public getWeekendDetailsRequest(){
    return this.httpClient.get(this.getWeekendDetailsAPI);
  }

  public getQuestionsListRequest(rewardType: any){
    return this.httpClient.get(this.getQuestionsListAPI+"/"+rewardType);
  }
  
  public doNominationRequest(nominationData: any):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'my-auth-token'
      })
    };
    return this.httpClient.post(this.doNominationAPI,nominationData,httpOptions);
  }

  public uploadNominationFile(file: File,RewardType: any): Observable<any> {
    const formdata: FormData = new FormData();
    formdata.append('file',file);
    formdata.append('REWARD_TYPE',RewardType);
    return this.httpClient.post(this.doNominationByExcelAPI,formdata,{  
    reportProgress: true
  });
   }
   public uploadCompoffConsolidateFile(file1: File,file2: File): Observable<any> {
    const formdata: FormData = new FormData();
    formdata.append('compOffFile',file1);
    formdata.append('employeeProjectInfo',file2);
    return this.httpClient.post(this.doCompoffConsolidationAPI,formdata);
   }
  public uploadFile(file: File,EMP_ID: any): Observable<any> {
    
    const formdata: FormData = new FormData();
    formdata.append('file',file);
    formdata.append('EMP_ID',EMP_ID);
    return this.httpClient.post(this.getWeekendDetailsAPI,formdata,{  
    reportProgress: true
  });
   }
   public 

   public getNominationReport(startDate,endDate,statusList:any)
   {
     return this.httpClient.post(this.nominationReportAPI+"/"+startDate+"/"+endDate,statusList,{ responseType: 'blob' as 'blob' });

   }
   public getWeekendReport(quarter,year,statusList:any)
   {
     return this.httpClient.post(this.weekendReportAPI+"/"+quarter+"/"+year,statusList,{ responseType: 'blob' as 'blob' });

   }
   public getCompOffExceptionReport(month,year)
   {
     return this.httpClient.get(this.getCompOffExceptionReportAPI+"/"+month+"/"+year,{ responseType: 'blob' as 'blob' });
   }
}