import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerQuarterComponent } from './manager-quarter.component';

describe('ManagerQuarterComponent', () => {
  let component: ManagerQuarterComponent;
  let fixture: ComponentFixture<ManagerQuarterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerQuarterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerQuarterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
