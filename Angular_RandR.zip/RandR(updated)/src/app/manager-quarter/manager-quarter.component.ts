import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { RestDataService } from '../rest-data.service' ;
import {Router} from '@angular/router';

@Component({
  selector: 'app-manager-quarter',
  templateUrl: './manager-quarter.component.html',
  styleUrls: ['./manager-quarter.component.css']
})
export class ManagerQuarterComponent implements OnInit {

  questionsList = [];
  commentsForm: FormGroup;
  constructor(private restDataService: RestDataService, private fb:FormBuilder,private router:Router) {}

  ngOnInit() {

    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    // console.log("Its In")
    this.restDataService.getQuestionsListRequest("Manager_of_the_Quarter").subscribe((resp: any[])=>{
      this.questionsList = resp;
      // console.log(this.questionsList);
  });
  this.commentsForm = this.fb.group({
    nomineeName: '',
    nomineeId: '',
    managerName: '',
    managerId: '',
    nominatorName: '',
    nominatorid: '',
    lob: '',
    duration: '',
    rewardType: 'Manager_of_the_Quarter',
    nominationRemarkList: this.fb.array([this.fb.group({remark:'',criteriaId:''})]),
  });
  }
  get questionComments() {
    
    return this.commentsForm.get("nominationRemarkList") as FormArray;
  }

  addComment()
  {
    this.questionComments.push(this.fb.group({remark:'',criteriaId:''}));
  }
  onSubmit() {
    this.restDataService.doNominationRequest(this.commentsForm.value).subscribe((response: any[])=>{
      console.log(response);
    });
    console.warn(this.commentsForm.value);
  }

  file: File;
  selectedFiles: FileList;
  currentFile: File;
  
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

upload() {
  this.file = this.selectedFiles.item(0);
    this.restDataService.uploadFile(this.file,'Manager_of_the_Quarter').subscribe((response: any[])=>{
  });    
}

}