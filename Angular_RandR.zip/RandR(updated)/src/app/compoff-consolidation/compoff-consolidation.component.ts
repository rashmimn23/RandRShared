import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../rest-data.service' ;
import {Router} from '@angular/router';


@Component({
  selector: 'app-compoff-consolidation',
  templateUrl: './compoff-consolidation.component.html',
  styleUrls: ['./compoff-consolidation.component.css']
})
export class CompoffConsolidationComponent implements OnInit {

  data:any;
  constructor(private restDataService: RestDataService,private router: Router) { }
  settings = {
  actions: {
  add: false,
  delete: false,
  edit:false
   },
    pager:{
      display:true,
      perPage:15
      },
      columns: {
       
        empId: {
      title: 'Employee Id',
      filter: true
      },
      empName: {
      title: 'Name',
      filter: true
      },
      compOffStatus: {
      title: 'CompOff Status',
      filter: true
      },
      absenseType: {
      title: 'Absence Type',
      filter: true
      },
      startDate : {
      title: 'Start Date',
      filter: true
      },
      endDate : {
      title: 'End Date',
      filter: true
      },
      offDay : {
        title: 'Work Date',
        filter: true
        },
      lob : {
      title: 'LOB',
      filter: true
      },
      projectId : {
      title: 'Project Id',
      filter: true
      },
      projectName : {
      title: 'Project Name',
      filter: true
     },
     location : {
      title: 'Location',
      filter: true
      },
      DeliveryManager : {
      title: 'Delivery Manager',
      filter: true
      },
      advanceCompOff : {
        title: 'Advance CompOff',
        filter: true
        },
        voucherStatus : {
          title: 'Voucher Status',
          filter: true
          },
      partOfWeeekendInterview : {
      title: 'Part Of Weekend Interview',
      filter: true
      },
      reason : {
      title: 'Reason',
      filter: true
      },
      comment: {
      title: 'Comment',
      filter: true
      },

      },
  
      attr: {
  
        class: 'table table-bordered'
  
      },
  
      defaultStyle: true
      
    };

  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
  }
  file1: File;
  file2: File;
  selectedFile1: FileList;
  selectedFile2: FileList;
  currentFile: File;
  
  selectFile1(event) {
    this.selectedFile1 = event.target.files;
  }
  selectFile2(event) {
    this.selectedFile2 = event.target.files;
  }

upload() {
  this.file1 = this.selectedFile1.item(0);
  this.file2 = this.selectedFile2.item(0);  
  this.restDataService.uploadCompoffConsolidateFile(this.file1,this.file2).subscribe((response: any[])=>{
      console.log(response);
      this.data=response;
  });    
}
}
