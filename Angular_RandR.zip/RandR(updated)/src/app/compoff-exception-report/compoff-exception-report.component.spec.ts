import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompoffExceptionReportComponent } from './compoff-exception-report.component';

describe('CompoffExceptionReportComponent', () => {
  let component: CompoffExceptionReportComponent;
  let fixture: ComponentFixture<CompoffExceptionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompoffExceptionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompoffExceptionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
