import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder,FormArray} from '@angular/forms';
import {DatePipe} from '@angular/common';
import { RestDataService } from '../rest-data.service' ;

@Component({
  selector: 'app-weekend-report',
  templateUrl: './weekend-report.component.html',
  styleUrls: ['./weekend-report.component.css'],
  providers: [DatePipe]
})
export class WeekendReportComponent implements OnInit {

  form: FormGroup;

  constructor(private datePipe: DatePipe,private restDataService: RestDataService, private fb: FormBuilder) {
    this.form = this.fb.group({
      startDate: new FormControl(new Date()),
    endDate: new FormControl(new Date()),
      checkArray: this.fb.array([])
    })
  }

  // statusList1=['Approved','Rejected','Pending','VoucherAlloted'];
  ngOnInit(){
    
  }


  onCheckboxChange(e) {
    const checkArray: FormArray = this.form.get('checkArray') as FormArray;
  
    if (e.target.checked) {
      checkArray.push(new FormControl(e.target.value));
    } else {
      let i: number = 0;
      checkArray.controls.forEach((item: FormControl) => {
        if (item.value == e.target.value) {
          checkArray.removeAt(i);
          return;
        }
        i++;
      });
    }
    console.log(checkArray);
  }

  onSubmit(){
    const date = this.form.value;
    date.startDate= this.datePipe.transform(date.startDate, 'yyyy-MM-dd');
    date.endDate= this.datePipe.transform(date.endDate, 'yyyy-MM-dd');
    // console.log(this.form.value.startDate);
    // console.log(this.form.value.endDate);
    // console.log(this.statusList);

    const isIE = /*@cc_on!@*/false || !!document['documentMode'];
    const isChrome = !!window['chrome'];

    this.restDataService.getNominationReport( date.startDate= this.datePipe.transform(date.startDate, 'yyyy-MM-dd'),date.endDate= this.datePipe.transform(date.endDate, 'yyyy-MM-dd'),this.form.value.checkArray).subscribe(fileData=>{
      const blob: any = new Blob([fileData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      if (isIE) { // this code doesn't work for chrome
      console.log('Manage IE download>10');
      window.navigator.msSaveOrOpenBlob(blob,"Weekend.xlsx");
  } else if (isChrome) {  // this below code doesn't work for IE
    const link = document.createElement('a');
    if (link.download !== undefined) {
     const url = URL.createObjectURL(blob);
     link.setAttribute('href', url);
     link.setAttribute('download',"Weekend.xlsx");
     link.setAttribute('target', '_self');
     document.body.appendChild(link);
     link.click();
     document.body.removeChild(link);
    }
  } else {
    window.navigator.msSaveOrOpenBlob(blob,"Weekend.xlsx");
  }
    })
  }
}
