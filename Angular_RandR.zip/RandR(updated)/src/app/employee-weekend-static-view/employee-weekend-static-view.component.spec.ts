import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeWeekendStaticViewComponent } from './employee-weekend-static-view.component';

describe('EmployeeWeekendStaticViewComponent', () => {
  let component: EmployeeWeekendStaticViewComponent;
  let fixture: ComponentFixture<EmployeeWeekendStaticViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeWeekendStaticViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeWeekendStaticViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
