import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { RestDataService } from '../rest-data.service' ;
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import {Router} from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-client-appreciation',
  templateUrl: './client-appreciation.component.html',
  styleUrls: ['./client-appreciation.component.css']
})
export class ClientAppreciationComponent implements OnInit {

  
  questionsList = [];
  commentsForm: FormGroup;
  constructor(private restDataService: RestDataService, private fb:FormBuilder,private http: HttpClient,private router: Router) {}

  ngOnInit() {

    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }

    // console.log("Its In")
    this.restDataService.getQuestionsListRequest("Client_Appreciation").subscribe((resp: any[])=>{
      this.questionsList = resp;
      // console.log(this.questionsList);
  });
  this.commentsForm = this.fb.group({
    nomineeName: '',
    nomineeId: '',
    managerName: '',
    managerId: '',
    nominatorName: '',
    nominatorid: '',
    lob: '',
    duration: '',
    rewardType: 'Client_Appreciation',
    nominationRemarkList: this.fb.array([this.fb.group({remark:'',criteriaId:''})]),
  });
  }
  get questionComments() {
    
    return this.commentsForm.get("nominationRemarkList") as FormArray;
  }

  addComment()
  {
    this.questionComments.push(this.fb.group({remark:'',criteriaId:''}));
  }
  onSubmit() {
    this.restDataService.doNominationRequest(this.commentsForm.value).subscribe((response: any[])=>{
      // console.log(response);
    });
    // console.warn(this.commentsForm.value);
  }

  file: File;
  selectedFiles: FileList;
  currentFile: File;
  
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

upload() {
  this.file = this.selectedFiles.item(0);
    this.restDataService.uploadNominationFile(this.file,'Client_Appreciation').pipe(
      catchError(this.handleError)
      ).subscribe((response: any[])=>{
     
      if(response)
      {
        alert("Upload Successfully");
      }
      else if(!response){
        alert("Not Uploaded Try Again...")
      }
  });    
}
handleError(error: HttpErrorResponse){
  alert("Not Uploaded Try Again...Make sure no duplicate data is uploaded")
  return throwError(error);
  }

}