import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardsPointsViewComponent } from './rewards-points-view.component';

describe('RewardsPointsViewComponent', () => {
  let component: RewardsPointsViewComponent;
  let fixture: ComponentFixture<RewardsPointsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardsPointsViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardsPointsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
