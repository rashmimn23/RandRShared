import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
 import { EmployeeRole } from './employee-role';
 import {Router} from '@angular/router';

 const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})

export class EmployeeRoleService {
  baseUrl:any;
  addUrl:any;
  updateUrl:any;
  deleteUrl:any;
  httpOptions: any;
  data:any;


constructor(private http: HttpClient,private router: Router) {
  this.baseUrl='http://localhost:8080/employeeRole/all';
  this.addUrl='http://localhost:8080/employeeRole/save';
  this.updateUrl='http://localhost:8080/employeeRole';
  this.deleteUrl='http://localhost:8080/employeeRole/deleteByid/';
 }

 ngOnInit(){
  if(sessionStorage.getItem('employeeRole')==null)
  {
    alert("Please Login First");
    this.router.navigate(['/login-view']);
  }
 }
  getAll():Observable<any>{
    return this.http.get(this.baseUrl);
  }
  add(emp: EmployeeRole):Observable<EmployeeRole> {
    return this.http.post<EmployeeRole>(this.addUrl, emp, httpOptions);
  }

  update(data){
  return this.http.put(`${this.updateUrl}/update`,data);
 }
 deleteRow(data){
 return this.http.delete<any>(this.deleteUrl+data);
 }
}