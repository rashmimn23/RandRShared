import { EmployeeRole } from './employee-role';

describe('EmployeeRole', () => {
  it('should create an instance', () => {
    expect(new EmployeeRole()).toBeTruthy();
  });
});
