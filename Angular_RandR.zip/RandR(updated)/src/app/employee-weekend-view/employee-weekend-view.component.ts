import { Component, OnInit } from '@angular/core';
import { WeekenddataService } from '../services/weekenddata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-weekend-view',
  templateUrl: './employee-weekend-view.component.html',
  styleUrls: ['./employee-weekend-view.component.css']
})
export class EmployeeWeekendViewComponent implements OnInit {
  selectedRows: any;
  selectedRowsid: any;
  arrselectedRowsid: [];
  i:any;
  constructor(private weekenddataservice:WeekenddataService,private router: Router ) { }
  settings = {
  
    actions: {
     add: false,
     edit: false,
     delete: false,
 
    },
     pager:{
       display:true,
       perPage:15
       },
       selectMode: 'multi',
       columns: {
         
         empId: {
           title: 'Emp_Id',
           filter: true,
           sort: false
         },
         empName: {
           title: 'Emp_Name',
           filter: true
         },
         rewardType: {
           title: 'MANAGER_NAME',
           filter: true
         },
         skill: {
           title: 'Skill',
           filter: true
         },
         location: {
           title: 'Location',
           filter: true
         },
         noOfInterviews: {
           title: 'No_Of_Interviews',
           filter: true
         },
         noOfPoints: {
           title: 'No_Of_Points',
           filter: true
         },
         dateOf: {
           title: 'Date_Of',
           filter: true
         },
         createdby: {
           title: 'Created_By',
           filter: true
         },
         modifiedBy: {
           title: 'Modified_By',
           filter: true
         },
         managerId: {
           title: 'Manager_Id',
           filter: true
         },
         advanceCompoff: {
           title: 'Advance_Compoff',
           filter: true
         },
         status : {
           title: 'Status',
           filter: true
         },
 
       },
   
       attr: {
         class: 'table table-bordered'
       },
   
       defaultStyle: true
       
     };
     Apply(event){
      console.log("Approve In Console");
               this.weekenddataservice.UpdateAdvanceCompOff(this.arrselectedRowsid,'Yes').subscribe(resp=>{   this.weekenddataservice.getbyId().subscribe(resp=>{
                this.data=resp;
              });
               });
           
      }
      // st='';
     rowClicked(event){
        // console.log(event.selected);
       this.selectedRows= event.selected;
      this.arrselectedRowsid=this.selectedRows.map(row => row.id);
      console.log("rowclicked array "+this.arrselectedRowsid);
    }
     data=[];
     data1:any;
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
    this.weekenddataservice.getbyId().subscribe(resp=>{
     for(let r of resp)
     {
       if(r.status=='Approved')
       this.data.push(r);
     }
     this.data1=this.data;
      // this.data=resp;
      console.log('>>getAll: ',this.data);
    });
  }

}
