import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FileUploadModule} from 'ng2-file-upload';
import{Ng2SmartTableModule} from 'ng2-smart-table';
import {Ng2CompleterModule} from 'ng2-completer';
import {HttpClientModule} from '@angular/common/http';
import {MatSidenavModule} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientViewComponent } from './employee-view/client-view.component';
import { ManagerViewComponent } from './manager-view/manager-view.component';
import { AdminViewComponent } from './admin-view/admin-view.component';
import { LoginViewComponent } from './login-view/login-view.component';
import {ClientAppreciationComponent} from './client-appreciation/client-appreciation.component';
import { WeekendInterviewComponent } from './weekend-interview/weekend-interview.component';
import {EmployeeRoleComponent} from './employee-role/employee-role.component';
import { RewardsPointsViewComponent } from './rewards-points-view/rewards-points-view.component';
import { InnovationAwardComponent } from './innovation-award/innovation-award.component';
import { EmployeeRewardsComponent } from './employee-rewards/employee-rewards.component';
import { SuperuserViewComponent } from './superuser-view/superuser-view.component';
import { HrviewComponent } from './hrview/hrview.component';
import { NominationTableComponent } from './nomination-table/nomination-table.component';
import { NominationcriteriaTableComponent } from './nominationcriteria-table/nominationcriteria-table.component';
import { PmoViewComponent } from './pmo-view/pmo-view.component';
import { OutstandingFlmComponent } from './outstanding-flm/outstanding-flm.component';
import { ManagerQuarterComponent } from './manager-quarter/manager-quarter.component';
import { ProgramQuarterComponent } from './program-quarter/program-quarter.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CompoffConsolidationComponent } from './compoff-consolidation/compoff-consolidation.component';
import { NominationTablePmoComponent } from './nomination-table-pmo/nomination-table-pmo.component';
import { VoucherDataComponent } from './voucher-data/voucher-data.component';
import { EmployeeWeekendViewComponent } from './employee-weekend-view/employee-weekend-view.component';
import { WeekendDataApproveComponent } from './weekend-data-approve/weekend-data-approve.component';
import { EmployeeNominationViewComponent } from './employee-nomination-view/employee-nomination-view.component';
import { EmployeeWeekendStaticViewComponent } from './employee-weekend-static-view/employee-weekend-static-view.component';
import { NominationReportComponent } from './nomination-report/nomination-report.component';
import { VoucherReportComponent } from './voucher-report/voucher-report.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { WeekendReportComponent } from './weekend-report/weekend-report.component';
import { CompoffExceptionReportComponent } from './compoff-exception-report/compoff-exception-report.component';



@NgModule({
  declarations: [
    AppComponent,
    ClientViewComponent,
    ManagerViewComponent,
    AdminViewComponent,
    LoginViewComponent,
    ClientAppreciationComponent,
    WeekendInterviewComponent,
    EmployeeRoleComponent,
    RewardsPointsViewComponent,
    InnovationAwardComponent,
    EmployeeRewardsComponent,
    SuperuserViewComponent,
    HrviewComponent,
    NominationTableComponent,
    NominationcriteriaTableComponent,
    PmoViewComponent,
    OutstandingFlmComponent,
    ManagerQuarterComponent,
    ProgramQuarterComponent,
    PageNotFoundComponent,
    CompoffConsolidationComponent,
    NominationTablePmoComponent,
    VoucherDataComponent,
    EmployeeWeekendViewComponent,
    WeekendDataApproveComponent,
    EmployeeNominationViewComponent,
    EmployeeWeekendStaticViewComponent,
    NominationReportComponent,
    VoucherReportComponent,
    WeekendReportComponent,
    CompoffExceptionReportComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FileUploadModule,
    FormsModule,ReactiveFormsModule,
    Ng2SmartTableModule,
    Ng2CompleterModule,
    MatSidenavModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
