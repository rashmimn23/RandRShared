import { Component, OnInit } from '@angular/core';
import{NominationserviceService} from '../services/nominationservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-nomination-view',
  templateUrl: './employee-nomination-view.component.html',
  styleUrls: ['./employee-nomination-view.component.css']
})
export class EmployeeNominationViewComponent implements OnInit {

  constructor(private nominationservice:NominationserviceService, private router: Router) { }
  settings = {
  
    actions: {
     add: false,
     edit: false,
     delete: false,
 
    },
     pager:{
       display:true,
       perPage:15
       },
       
       columns: {
         
         nomineeName: {
           title: 'NOMINEE_NAME',
           filter: true,
           sort: false
         },
         nomineeId: {
           title: 'NOMINEE_ID',
           filter: true
         },
         managerName: {
           title: 'MANAGER_NAME',
           filter: true
         },
         managerId: {
           title: 'MANAGER_ID',
           filter: true
         },
         nominatorName: {
           title: 'NOMINATOR_NAME',
           filter: true
         },
         nominatorid: {
           title: 'NOMINATOR_ID',
           filter: true
         },
         lob: {
           title: 'LOB',
           filter: true
         },
         rewardType: {
           title: 'REWARD_TYPE',
           filter: true
         },
         nominationStatus: {
           title: 'NOMINATION_STATUS',
           filter: true
         },
         nominationDate: {
           title: 'NOMINATION_DATE',
           filter: true
         },
         pmoId: {
           title: 'PMO_ID',
           filter: true
         },
 
       },
   
       attr: {
         class: 'table table-bordered'
       },
   
       defaultStyle: true
       
     };
     data:any;
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    this.nominationservice.getbyId().subscribe(resp=>{
      this.data=resp;
      console.log('>>getbyId: ',resp);
    });
  
  }

}
