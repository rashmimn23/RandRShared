import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeNominationViewComponent } from './employee-nomination-view.component';

describe('EmployeeNominationViewComponent', () => {
  let component: EmployeeNominationViewComponent;
  let fixture: ComponentFixture<EmployeeNominationViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeNominationViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeNominationViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
