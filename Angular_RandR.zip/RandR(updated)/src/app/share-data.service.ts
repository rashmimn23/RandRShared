import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/internal/Subject';
// import { Subject } from 'rxjs/Subject';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {

  shareDataSubject = new Subject<any>();
  sendDataToOtherComponent(somedata: any){
    this.shareDataSubject.next(somedata);
}

}
