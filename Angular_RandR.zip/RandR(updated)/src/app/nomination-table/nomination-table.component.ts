import { Component, OnInit } from '@angular/core';
// import{ServiceService} from '../services/service.service';
import { Router, RouterModule } from '@angular/router';
import{NominationserviceService} from '../services/nominationservice.service';

@Component({
  selector: 'app-nomination-table',
  templateUrl: './nomination-table.component.html',
  styleUrls: ['./nomination-table.component.css']
})
export class NominationTableComponent implements OnInit {
  //router: any;

  constructor(private nominationservice:NominationserviceService, private router: Router) { }
  //constructor(private nominationservice:NominationserviceService) { }
  settings = {
    edit:{editButtonContent:'EDIT',
    UpdateButtonContent:'SAVE',
    cancleButtonContenet:'CANCLE',
    confirmSave: true,
   },
   add: {
     inputClass: '',
     addButtonContent: 'ADD NEW',
     createButtonContent: 'CREATE',
     cancelButtonContent: 'CANCLE',
     confirmCreate: true,
 },
 delete: {
  deleteButtonContent: 'DELETE',
  cancelButtonContent: 'CANCEL',
  confirmDelete: true
  },
   action: {
  add: true,
  delete: true
   },
    pager:{
      display:true,
      perPage:15
      },
      actions: {
        custom: [
          {
            name: 'remark',
            title: 'Remark ',
          }
        ],
      },
      columns: {
       
        nomineeName: {
          title: 'NOMINEE_NAME',
          filter: true
        },
        nomineeId: {
          title: 'NOMINEE_ID',
          filter: true
        },
        managerName: {
          title: 'MANAGER_NAME',
          filter: true
        },
        managerId: {
          title: 'MANAGER_ID',
          filter: true
        },
        nominatorName: {
          title: 'NOMINATOR_NAME',
          filter: true
        },
        nominatorid: {
          title: 'NOMINATOR_ID',
          filter: true
        },
        lob: {
          title: 'LOB',
          filter: true
        },
        rewardType: {
          title: 'REWARD_TYPE',
          filter: true
        },
        nominationStatus: {
          title: 'NOMINATION_STATUS',
          filter: true
        },
        nominationDate: {
          title: 'NOMINATION_DATE',
          filter: true
        },
        pmoId: {
          title: 'PMO_ID',
          filter: true
        },
     

      },
  
      attr: {
  
        class: 'table table-bordered'
  
      },
  
      defaultStyle: true
      
    };
    onDeleteConfirm(event) {
        this.nominationservice.deleteRow(event.data.id).subscribe(resp=>{ console.log(resp);
                  event.confirm.resolve(event.source.data);});
      
    }
    
      data: any;
      remarkList:any;
      remarks:any;
  ngOnInit() {
    if(sessionStorage.getItem('employeeRole')==null)
    {
      alert("Please Login First");
      this.router.navigate(['/login-view']);
    }
    this.nominationservice.getAll().subscribe(resp=>{
      this.data=resp;
      // console.log('>>getAll: ',resp);
    });
  }
  remark(event) {
   
    // if(event.data.id==this.data.id)
    for(let d of this.data)
    {
      if(event.data.id==d.id)
      {
      this.remarkList = d.nominationRemarkList;
      }
    }
  for(let r of this.remarkList) 
  {
     this.remarks=r.remark;
    }
    console.log(this.remarks);
    }
   

}
