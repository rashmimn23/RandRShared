import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NominationTablePmoComponent } from './nomination-table-pmo.component';

describe('NominationTablePmoComponent', () => {
  let component: NominationTablePmoComponent;
  let fixture: ComponentFixture<NominationTablePmoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NominationTablePmoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NominationTablePmoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
