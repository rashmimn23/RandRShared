import { Component, OnInit } from '@angular/core';
import {RestDataService } from '../rest-data.service';
import {Router} from '@angular/router'


@Component({
  selector: 'app-client-view',
  templateUrl: './client-view.component.html',
  styleUrls: ['./client-view.component.css']
})

export class ClientViewComponent implements OnInit {

  
  // employees = [];
  EmployeeName = '';
  constructor(private restDataService: RestDataService, private router: Router) { }
 
  //   settings = {
  //   actions: {
  //  add: false,
  //  delete: false,
  //  edit: false
  //   },
  //   pager:{
  //     display:true,
  //     perPage:15
  //     },
     
    
    
  //     columns: {
  //       empName: {
  //         title: 'Employee Name',
  //         filter: true
  //       },
  //       empId: {
  //         title: 'Employee Id',
  //         filter: true
  
  //       },
  //       rewardType: {
  //         title: 'Type of Reward',
  //         filter: true
  
  //       },
  //       noOfInterviews:{
  //         title: 'No. of Interview',
  //         filter: true
  
  //       },
  //       dateOf :{
  //         title: 'Date',
  //         filter: true
  
  //       },
  //       managerId :{
  //         title: 'Manager Id',
  //         filter: true
  
  //       },

  //       advanceCompoff :{
  //         title: 'Advance CompOff',
  //         filter: true
  
  //       },
     
  //       noOfPoints :{
  //         title: 'No. of Points',
  //         filter: true
  
  //       },
     
  //       createdby :{
  //         title: 'Created By',
  //         filter: true
  
  //       },
  //       modifiedBy :{
  //         title: 'Modified By',
  //         filter: true
  
  //       },
     
  //       status :{
  //         title: 'Status',
  //         filter: true
  
  //       }
     
         
     
  //     },
    
  //   attr: {
  //     class: 'table table-bordered ' 
  
  //   },
  //   defaultStyle:true,
  
  //   };
    private loadComponent = 'nomination_table';
    private loadComponent1= 'weekend_static_view';
    loadMyChildComponent(reward_type: any){
      console.log(reward_type);
       this.loadComponent = reward_type;
    }
    loadMyChildComponent1(reward_type: any){
      console.log(reward_type);
       this.loadComponent1 = reward_type;
    }

    private loginStatus = '';
    logout()
    {
      this.loginStatus='';
      sessionStorage.clear();
          this.router.navigate(['/login-view']);
    }


  ngOnInit() {

    if(sessionStorage.getItem('employeeRole')!='EMPLOYEE')
    {
      alert("Please Login First");
      sessionStorage.clear();
      this.router.navigate(['/login-view']);
    }
   else if(sessionStorage.getItem('employeeRole')=='EMPLOYEE'){
    this.EmployeeName = sessionStorage.getItem('employeeName');
    this.loginStatus='true';

    // console.log(sessionStorage.getItem('employeeId'));
    // this.restDataService.singleEmployeeDetailsRequest(sessionStorage.getItem('employeeId')).subscribe((restData: any[])=>{
    //   this.employees = restData;
  // });
}
  }
}
  

