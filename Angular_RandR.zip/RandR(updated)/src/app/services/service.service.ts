import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Point } from '../admin-view/Point';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
baseUrl:any;
addUrl:any;
updateUrl:any;
httpOptions: any;
deleteUrl:any;

  constructor(private http: HttpClient) { 
  this.baseUrl='http://localhost:8080/points/all';
  this.addUrl='http://localhost:8080/points/save';
  this.updateUrl='http://localhost:8080/points';
  this.deleteUrl='http://localhost:8080/points/deleteByid/';

  }
 getAll():Observable<any>{
 
   return this.http.get(this.baseUrl);
 }

 addPoint (point: Point): Observable<Point> {
   return this.http.post<Point>(this.addUrl, point, httpOptions);
 }
 update(data){
 return this.http.put(`${this.updateUrl}/update`,data);
}
 deletePoint(data){
  
     return this.http.delete<any>(this.deleteUrl+data);
  }

}