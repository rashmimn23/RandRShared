import { TestBed } from '@angular/core/testing';

import { NominationserviceService } from './nominationservice.service';

describe('NominationserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NominationserviceService = TestBed.get(NominationserviceService);
    expect(service).toBeTruthy();
  });
});
