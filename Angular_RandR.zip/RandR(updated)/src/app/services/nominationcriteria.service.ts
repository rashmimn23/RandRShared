import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Point } from '../admin-view/Point';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};
@Injectable({
  providedIn: 'root'
})
export class NominationcriteriaService {
  fetchnaminationctiteriaUrl:any;
  addnominationctiteriaUrl:any;
   updatenominationctiteriaUrl:any;
   deletenominationctiteriaUrl:any;
  httpOptions: any;
  constructor(private http: HttpClient) { 
     this.addnominationctiteriaUrl='http://localhost:8080/nominationCriteria/save';
     this.fetchnaminationctiteriaUrl='http://localhost:8080/nominationCriteria/all';
     this.updatenominationctiteriaUrl='http://localhost:8080/nominationCriteria';
     this.deletenominationctiteriaUrl='http://localhost:8080/nominationCriteria/deleteByid/'; 
  
    }
    getAll():Observable<any>{
   
      return this.http.get(this.fetchnaminationctiteriaUrl);
    }
    addPoint (point: Point): Observable<Point> {
      return this.http.post<Point>(this.addnominationctiteriaUrl, point, httpOptions);
    }
    update(data){
   
    return this.http.put(`${this.updatenominationctiteriaUrl}/update`,data);
   
   }
   deleteRow(data){
  
    return this.http.delete<any>(this.deletenominationctiteriaUrl+data);
 }
}
