import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Point } from '../admin-view/Point';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})
export class NominationserviceService {
fetchnaminationUrl:any;
addnominationUrl:any;
updatenominationUrl:any;
httpOptions: any;
deleteUrl:any;
approveUrl:any;
appr:any;
fetchbyId:any;

constructor(private http: HttpClient) { 
  this.addnominationUrl='http://localhost:8080/nomination/save';
  this.fetchnaminationUrl='http://localhost:8080/nomination/all';
  this.updatenominationUrl='http://localhost:8080/nomination';
  this.deleteUrl='http://localhost:8080/nomination/deleteById/';
  this.approveUrl='http://localhost:8080/nomination';
  this.fetchbyId='http://localhost:8080/nomination/getByNomineeId/';



  }
  getAll():Observable<any>{
 
    return this.http.get(this.fetchnaminationUrl);
  }
  deleteRow(data){
  
    return this.http.delete<any>(this.deleteUrl+data);
 }
 getbyId():Observable<any>{
  // sessionStorage.setItem('employeeId','2373950');
  return this.http.get(this.fetchbyId+sessionStorage.getItem('employeeId'));
  }

  statusUpdate(selectedRowsIDs,selectedRowsRTs, status) {
    console.log(status);
   const formData: FormData = new FormData();
   formData.append('ID',selectedRowsIDs);
   formData.append('REWARD_TYPE',selectedRowsRTs);
   formData.append('NOMINATION_STATUS',status);
   return this.http.put(`${this.approveUrl}/statusUpdate`,formData);
      
  }
  // statusUpdateR(selectedRowsIDs,selectedRowsRTs, status) {

  //  console.log(status);
  //  const formData: FormData = new FormData();
  //  formData.append('ID',selectedRowsIDs);
  //  formData.append('REWARD_TYPE',selectedRowsRTs);
  //  formData.append('NOMINATION_STATUS',status);
  //  return this.http.put(`${this.approveUrl}/statusUpdate`,formData);
 

  // }

}
