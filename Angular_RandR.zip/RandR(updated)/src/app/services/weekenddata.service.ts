import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};
@Injectable({
  providedIn: 'root'
})
export class WeekenddataService {
  fetchallUrl:any;
  fetchbyidUrl:any;
  httpOptions: any;
  updateUrl:any;
  comoffupdate: any;
  appr:any;
  
  constructor(private http: HttpClient) {

    this.fetchallUrl='http://localhost:8080/employeeRewards/all';
    this.fetchbyidUrl='http://localhost:8080/employeeRewards/getByEmployeeId/';
    this.updateUrl='http://localhost:8080/employeeRewards';
    this.comoffupdate='http://localhost:8080/employeeRewards/UpdateAdvanceCompOff/';


  
   }
  getAll():Observable<any>{
 
    return this.http.get(this.fetchallUrl);
  }
  getbyId():Observable<any>{
    // sessionStorage.setItem('employeeId','2347303');
    
    return this.http.get(this.fetchbyidUrl+sessionStorage.getItem('employeeId') );
  }
  statusUpdate(selectedRowsIDs, status) {
  console.log(status);
   const formData: FormData = new FormData();
   formData.append('ID',selectedRowsIDs);
   formData.append('STATUS',status);
   console.log(formData);
   return this.http.put(`${this.updateUrl}/statusUpdate`,formData);
   
      
  }
  UpdateAdvanceCompOff(selectedRowsIDs:any, status) {
      return this.http.put(this.comoffupdate+status,selectedRowsIDs);
        
    }
 
}
