import { Component, OnInit } from '@angular/core';
import { EmployeeRewardsService } from './employee-rewards.service';

@Component({
  selector: 'app-employee-rewards',
  templateUrl: './employee-rewards.component.html',
  styleUrls: ['./employee-rewards.component.css']
})
export class EmployeeRewardsComponent implements OnInit {
  constructor(private service: EmployeeRewardsService) {}

  settings = {
    edit:{editButtonContent:'EDIT',
   UpdateButtonContent:'SAVE',
   cancleButtonContenet:'CANCLE',
   confirmSave: true,
   delete: {
    confirmDelete: true,
  },
  },
  add: {
    inputClass: '',
    addButtonContent: 'Add New',
    createButtonContent: 'Create',
    cancelButtonContent: 'Cancel',
    confirmCreate: true,
},
  
delete: {
  deleteButtonContent: 'Delete',
  cancelButtonContent: 'Cancel',
 confirmDelete: true,
},
actions: {
add: true,
delete:true
},

  pager:{
    display:true,
    perPage:15
    },

  
    columns: {
      empId: {
        title: 'Employee Id',
        filter: true
      },
      empName: {
        title: 'Employee Name',
        filter: true

      },
      noOfInterviews: {
        title: 'NO_OF_INTERVIEWS',
        filter: true

      },
      noOfPoints:{
        title: 'NO_OF_POINTS',
        filter: true

      },
      dateOf :{
        title: 'DATE_OF',
        filter: true

      },
      createdby :{
        title: 'CREATED_BY',
        filter: true
      },
      advanceCompoff :{
        title: 'ADVANCE_COMPOFF',
        filter: true

      },
      eligibleForCompoff :{
        title: 'ELIGIBLE_FOR_COMPOF',
        filter: true

      }
      
    },
  attr: {
    class: 'table table-bordered'
     //table-success 

  },
  defaultStyle:true
};
onEditConfirm($event){
  // console.log("Edit Event In Console")
}
onSaveConfirm(event){
// console.log("Edit Event In Console")
// console.log(event);
event.confirm.resolve();
this.service.update(event.newData).subscribe(resp=>{   
});
 
}
data: any;

onCreateConfirm(event){
  event.confirm.resolve();

}



 ondeleteConfirm(event)
 {
   this.service.deleteRow(event.data.id).subscribe(resp=>{console.log(resp);
       event.confirm.resolve(event.source.data);});
  
 }
 
  ngOnInit() {
   this.service.getAll().subscribe(resp=>{
     this.data=resp;
    //  console.log('>>getAll: ',resp);
   });
     }
  }
 


  