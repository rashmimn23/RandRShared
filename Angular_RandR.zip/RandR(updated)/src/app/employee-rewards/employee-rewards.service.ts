import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { EmployeeRewards } from './employee-rewards';
import {Router} from '@angular/router';

 const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token',
  
  })
};

@Injectable({
  providedIn: 'root'
})

export class EmployeeRewardsService {
  baseUrl:any;
  addUrl:any;
  updateUrl:any;
  deleteUrl:any;
  httpOptions: any;
  data:any;


constructor(private http: HttpClient,private router: Router) {
  this.baseUrl='http://localhost:8080/employeeRewards/all';
  this.addUrl='http://localhost:8080/employeeRewards/save';
  this.updateUrl='http://localhost:8080/employeeRewards';
  this.deleteUrl='http://localhost:8080/employeeRewards/deleteByid/';
 
 }
 ngOnInit()
 {
  if(sessionStorage.getItem('employeeRole')==null)
  {
    alert("Please Login First");
    this.router.navigate(['/login-view']);
  }
 }
  getAll():Observable<any>{
    return this.http.get(this.baseUrl);
  }
  add(emp: EmployeeRewards):Observable<EmployeeRewards> {
    return this.http.post<EmployeeRewards>(this.addUrl, emp, httpOptions);
  }

  update(data){
  return this.http.put(`${this.updateUrl}/update`,data);
 }
 deleteRow(data){
  return this.http.delete<any>(this.deleteUrl+data);
  };
 }

