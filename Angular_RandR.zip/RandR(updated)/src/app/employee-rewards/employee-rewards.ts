export class EmployeeRewards {
}
