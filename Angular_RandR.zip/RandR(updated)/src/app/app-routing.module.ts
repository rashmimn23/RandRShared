import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientViewComponent } from './employee-view/client-view.component';
import {ManagerViewComponent} from './manager-view/manager-view.component';
import {AdminViewComponent} from './admin-view/admin-view.component';
import {LoginViewComponent} from './login-view/login-view.component';
import {ClientAppreciationComponent} from './client-appreciation/client-appreciation.component';
import {WeekendInterviewComponent} from './weekend-interview/weekend-interview.component';
import {EmployeeRoleComponent} from './employee-role/employee-role.component';
import { RewardsPointsViewComponent } from './rewards-points-view/rewards-points-view.component';
import {InnovationAwardComponent} from './innovation-award/innovation-award.component';
import {EmployeeRewardsComponent} from './employee-rewards/employee-rewards.component' ;
import {SuperuserViewComponent} from './superuser-view/superuser-view.component';
import {HrviewComponent} from './hrview/hrview.component';
import {NominationTableComponent} from './nomination-table/nomination-table.component';
import {NominationcriteriaTableComponent} from './nominationcriteria-table/nominationcriteria-table.component';
import {OutstandingFlmComponent} from './outstanding-flm/outstanding-flm.component';
import {ManagerQuarterComponent} from './manager-quarter/manager-quarter.component';
import {ProgramQuarterComponent} from './program-quarter/program-quarter.component';
import {PmoViewComponent} from './pmo-view/pmo-view.component';
import {PageNotFoundComponent} from './page-not-found/page-not-found.component';
import {CompoffConsolidationComponent} from './compoff-consolidation/compoff-consolidation.component';
import {NominationTablePmoComponent} from './nomination-table-pmo/nomination-table-pmo.component';
import {VoucherDataComponent} from './voucher-data/voucher-data.component';
import {EmployeeWeekendViewComponent} from './employee-weekend-view/employee-weekend-view.component';
import {WeekendDataApproveComponent} from './weekend-data-approve/weekend-data-approve.component';
import {EmployeeNominationViewComponent} from './employee-nomination-view/employee-nomination-view.component';
import {EmployeeWeekendStaticViewComponent} from './employee-weekend-static-view/employee-weekend-static-view.component';
import { from } from 'rxjs';

const routes: Routes = [
  // {path: 'employee-view',component: ClientViewComponent},
  {path: 'employee-view',component: ClientViewComponent},
  // {path: 'manager-view',component: ManagerViewComponent},
  {path: 'rewards-points',component: RewardsPointsViewComponent},
  {path: 'manager-view',component: ManagerViewComponent},
  {path: 'admin-view',component: AdminViewComponent},
  {path: 'login-view',component: LoginViewComponent},
  {path: 'client-appreciation',component: ClientAppreciationComponent},
  {path: 'weekend-interview',component: WeekendInterviewComponent},
  {path: 'employee-rewards', component: EmployeeRewardsComponent},
  {path: 'employee-role',component: EmployeeRoleComponent},
  {path: 'innovation-award', component: InnovationAwardComponent},
  {path: 'superuser-view', component: SuperuserViewComponent},
  {path: 'hr-view',component: HrviewComponent},
  {path: 'nomination-table',component: NominationTableComponent},
  {path: 'nominationcriteria-table', component: NominationcriteriaTableComponent},
  {path: 'outstanding-flm', component: OutstandingFlmComponent},
  {path: 'manager-quarter', component: ManagerQuarterComponent},
  {path: 'program-quarter', component: ProgramQuarterComponent},
  {path: 'pmo-view', component:PmoViewComponent},
  {path: 'compoff-consolidation', component: CompoffConsolidationComponent},
  {path: 'nomination-pmo', component: NominationTablePmoComponent},
  {path: 'voucher-data', component: VoucherDataComponent},
  {path: 'weekend-approve', component: WeekendDataApproveComponent},
  {path: 'employee-weekend',component: EmployeeWeekendViewComponent},
  { path: 'employee-nomination', component: EmployeeNominationViewComponent},
  {path: 'employee-weekend-static', component: EmployeeWeekendStaticViewComponent},
  {path: '', component:LoginViewComponent},
  {path: '**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
