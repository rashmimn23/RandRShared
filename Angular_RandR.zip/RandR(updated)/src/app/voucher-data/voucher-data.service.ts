import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { VoucherDataComponent } from './voucher-data.component';

const httpOptions = {
  
};
@Injectable({
  providedIn: 'root'
})
export class VoucherDataService {

 
     baseUrl:any;
    addUrl:any;
    updateUrl:any;
    deleteUrl:any;
    httpOptions: any;
    data:any;
    getQuarterlyNomination:any;
    getQuarterlyReward:any;
    processVoucherData:any;
    downloadVoucherData:any;
  
  
  constructor(private http: HttpClient) {
    this.baseUrl='http://localhost:8080//voucherData/all';
    this.addUrl='http://localhost:8080//voucherData/save';
    this.updateUrl='http://localhost:8080//voucherData"';
    this.deleteUrl='http://localhost:8080//voucherData/deleteByid/';
    this.getQuarterlyNomination='http://localhost:8080//voucherData/getQuarterlyNomination';
    this.getQuarterlyReward='http://localhost:8080//voucherData/getQuarterlyReward';
    this.processVoucherData='';
    this.downloadVoucherData='http://localhost:8080//reports/downloadQuarterlyVoucher';

   }
    getAll():Observable<any>{
      return this.http.get(this.baseUrl);
    }
    add(emp: VoucherDataComponent):Observable<VoucherDataComponent> {
      return this.http.post<VoucherDataComponent>(this.addUrl, emp);
    }
  
    update(data){
    return this.http.put(`${this.updateUrl}/update`,data);
   }
   deleteRow(data){
   return this.http.delete<any>(this.deleteUrl+data);
   }
   getQuarterlyNominationRequest(QUARTER:any,YEAR:any)
   {
     return this.http.get(this.getQuarterlyNomination+'/'+QUARTER+'/'+YEAR);
   }
   getQuarterlyRewardRequest(QUARTER:any,YEAR:any)
   {
     return this.http.get(this.getQuarterlyReward+'/'+QUARTER+'/'+YEAR);
   }
   downloadVoucherDataRequest(QUARTER:any,YEAR:any,REWARDTYPE:any)
   {
     return this.http.get(this.downloadVoucherData+"/"+QUARTER+"/"+YEAR+"/"+REWARDTYPE,{ responseType: 'blob' as 'blob' });
   }
   processVoucherDataRequest()
   {
     return this.http.get(this.processVoucherData);
   }
  }