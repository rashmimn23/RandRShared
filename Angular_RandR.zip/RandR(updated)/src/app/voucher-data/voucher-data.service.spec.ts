import { TestBed } from '@angular/core/testing';

import { VoucherDataService } from './voucher-data.service';

describe('VoucherDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VoucherDataService = TestBed.get(VoucherDataService);
    expect(service).toBeTruthy();
  });
});
