import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { RestDataService } from '../rest-data.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ShareDataService } from '../share-data.service';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';



@Component({
  selector: 'app-login-view',
  templateUrl: './login-view.component.html',
  styleUrls: ['./login-view.component.css']
})
export class LoginViewComponent {

  private employeeRole = '';
  constructor(private restDataService: RestDataService, private router: Router, private dataShareService: ShareDataService) { }
  loginForm = new FormGroup({

    employeeId: new FormControl(''),
    password: new FormControl('')
  });
  ngOnInit() {
    if (sessionStorage.getItem('employeeRole') != null) {
      // console.log("NOT NULL");
      this.employeeRole = sessionStorage.getItem('employeeRole');
      this.navig(this.employeeRole);

    }
    else if (sessionStorage.getItem('employeeRole') == null)
      sessionStorage.clear();
  }

  passData() {
    this.dataShareService.sendDataToOtherComponent(this.loginForm.value.employeeId);
  }


  navig(employeeRole: any) {

    switch (employeeRole) {

      case "MANAGER":
        {
          this.router.navigate(['/manager-view']);

          break;
        }
      case "ADMIN":
        {
          this.router.navigate(['/admin-view']);
          break;
        }
      case "EMPLOYEE":
        {
          this.passData();
          this.router.navigate(['/employee-view']);
          break;
        }
      case "SUPERUSER":
        {
          this.router.navigate(['/superuser-view']);
          break;
        }
      case "HR":
        {
          this.router.navigate(['/hr-view']);
          break;
        }
      case "PMO":
        {
          this.router.navigate(['/pmo-view']);
          break;
        }
      default:
        {
          alert("Enter Valid Credentials");
        }

    }
  }

  onSubmit() {
    this.restDataService.loginInfoRequest(this.loginForm.value.employeeId, this.loginForm.value.password).pipe(
      catchError(this.handleError)
    ).subscribe((resp: any) => {
      if (resp) {
        sessionStorage.setItem('employeeId', this.loginForm.value.employeeId);
        sessionStorage.setItem('password', this.loginForm.value.password);
        sessionStorage.setItem('employeeName', resp.empName);
        sessionStorage.setItem('employeeRole', resp.empRole);
        this.navig(resp.empRole);
      }
      else
        alert("Enter Valid Credentials");
    })

  }
  handleError(error: HttpErrorResponse) {
    alert("Enter Valid Credentials")
    return throwError(error);
  }

}
